var fruits = ["one": "Banana", "two": "Apple", "three": "Pear"]

for key in fruits.keys {
   if key == "two" {
      print("We have an element with the key ‘two’")
   }
}
