var list = ["First": "Apple", "Second": "Orange"]
if let first = list["First"], let second = list["Second"] {
   print("We have \(first) and \(second)")  // "We have Apple and Orange"
}
