var age = String(44)
var mytext = "Total digits \(age.count)"  // "Total digits 2"
