var text = "Hello World"
text.insert("!", at: text.endIndex)

print("New string is \(text)")  // "New string is Hello World!"
