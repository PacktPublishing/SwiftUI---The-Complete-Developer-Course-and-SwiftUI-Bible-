var total = 0
for value in 0...10 {
   total += value
}
print("The total is \(total)")  // "The total is 55"
