var list = [15, 25, 35]
list = []
