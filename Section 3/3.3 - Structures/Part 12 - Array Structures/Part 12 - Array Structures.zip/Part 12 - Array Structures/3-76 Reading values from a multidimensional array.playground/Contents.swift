var list: [[Int]] = [[2, 45, 31], [5, 10], [81, 12]]
print(list[1][0])  // 5  
