let list = [2, 4, 8, 16]
let half = list.map({ $0 / 2 })
print(half)  // "[1, 2, 4, 8]"
