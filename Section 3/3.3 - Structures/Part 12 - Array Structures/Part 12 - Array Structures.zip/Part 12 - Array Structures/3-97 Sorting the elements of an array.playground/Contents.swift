var fruits = ["Blueberry", "Apple", "Banana"]
let basket = fruits.sorted()
print(basket)  // ["Apple", "Banana", "Blueberry"]
