let ages = [32, 540, 12, 27, 54]

if let index = ages.firstIndex(of: 540) {
   print("The value is at the position \(index)")  // 1
}
