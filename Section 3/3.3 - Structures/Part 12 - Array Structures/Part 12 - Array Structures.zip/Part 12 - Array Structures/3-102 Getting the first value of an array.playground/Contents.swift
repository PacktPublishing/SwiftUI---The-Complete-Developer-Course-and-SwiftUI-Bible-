let ages = [32, 540, 12, 27]

if let firstAge = ages.first {
   print("The first person is \(firstAge) years old")  // 32
}
