let ages = [32, 540, 12, 27]

if let older = ages.max() {
   let digits = String(older)
   print("The maximum age is \(digits.count) digits long")
}
