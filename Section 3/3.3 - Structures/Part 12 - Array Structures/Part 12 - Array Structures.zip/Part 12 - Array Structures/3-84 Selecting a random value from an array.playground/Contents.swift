let fruits = ["Banana", "Orange", "Apple"]
if let randomValue = fruits.randomElement() {
   print("The selected value is: \(randomValue)")
}
