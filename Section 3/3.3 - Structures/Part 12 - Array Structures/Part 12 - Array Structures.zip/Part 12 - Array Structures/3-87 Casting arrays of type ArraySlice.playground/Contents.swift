var fruits = ["Banana", "Orange", "Apple", "Cherry"]
var someFruits = fruits[0..<2]  // ["Banana", "Orange"]
var newArray = Array(someFruits)
