var fruits = ["Banana", "Orange", "Apple"]
fruits = fruits.shuffled()
print(fruits)  // e.g.: ["Orange", "Apple", "Banana"]
