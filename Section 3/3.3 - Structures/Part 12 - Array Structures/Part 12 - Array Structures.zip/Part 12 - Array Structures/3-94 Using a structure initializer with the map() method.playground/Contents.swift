let list = [1, 2, 3, 4, 5]
let listtext = list.map(String.init)
print(listtext)  // "["1", "2", "3", "4", "5"]"
