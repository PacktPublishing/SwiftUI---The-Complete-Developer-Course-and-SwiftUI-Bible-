var ages: Set = [15, 25, 35, 45]
for age in ages {
   if age == 35 {
      print("There is a 35")  // "There is a 35"
      break
   }
}
