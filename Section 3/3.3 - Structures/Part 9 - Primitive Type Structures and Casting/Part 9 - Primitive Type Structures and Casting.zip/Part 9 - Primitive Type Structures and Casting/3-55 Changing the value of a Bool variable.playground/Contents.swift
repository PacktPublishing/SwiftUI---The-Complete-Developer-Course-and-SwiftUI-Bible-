var valid: Bool = true
if valid {
   print("It is Valid")
   valid.toggle()
}
print(valid)  // false

