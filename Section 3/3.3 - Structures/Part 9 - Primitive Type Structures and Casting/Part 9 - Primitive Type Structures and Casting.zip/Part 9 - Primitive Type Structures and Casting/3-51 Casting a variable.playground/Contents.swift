var number1: Int = 10
var number2: Double = 2.5
var total = Double(number1) / number2  // 4.0
