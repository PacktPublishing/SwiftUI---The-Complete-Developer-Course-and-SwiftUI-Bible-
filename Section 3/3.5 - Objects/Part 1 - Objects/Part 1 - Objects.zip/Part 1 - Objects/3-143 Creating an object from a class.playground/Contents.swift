class Employee {
   var name = "Undefined"
   var age = 0
}
let employee1 = Employee()
employee1.name = "John"
employee1.age = 32
