class Employee {
   var name: String
   var age: Int
    
   init(name: String, age: Int) {
      self.name = name
      self.age = age
   }
}
let employee1 = Employee(name: "George", age: 28)
