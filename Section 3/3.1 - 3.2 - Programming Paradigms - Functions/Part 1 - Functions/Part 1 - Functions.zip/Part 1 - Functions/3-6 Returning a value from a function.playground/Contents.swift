func double(number: Int) -> Int {
   let total = number * 2
   return total
}
let result = double(number: 25)
let message = "The result is \(result)"  // "The result is 50"
