var mynumber = 5
var counter = 0

func myfunction() {
   mynumber = mynumber * 2  // 160
}
while counter < 5 {
   myfunction()
   counter += 1
}
