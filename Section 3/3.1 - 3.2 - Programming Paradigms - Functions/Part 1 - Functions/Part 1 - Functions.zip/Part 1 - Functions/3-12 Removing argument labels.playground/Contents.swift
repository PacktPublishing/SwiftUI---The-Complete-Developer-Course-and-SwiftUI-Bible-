func multiply(number1: Int, _ number2: Int) -> Int {
   number1 * number2
}
let result = multiply(number1: 25, 3)
let message = "The result is \(result)"  // "The result is 75"
