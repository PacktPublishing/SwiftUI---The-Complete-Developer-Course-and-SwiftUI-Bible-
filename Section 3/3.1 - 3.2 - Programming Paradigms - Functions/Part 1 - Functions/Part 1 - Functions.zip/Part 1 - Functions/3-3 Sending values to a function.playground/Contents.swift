func double(number: Int) {
   let total = number * 2
   let message = "Result: \(total)"  // "Result: 10"
}
double(number: 5)
