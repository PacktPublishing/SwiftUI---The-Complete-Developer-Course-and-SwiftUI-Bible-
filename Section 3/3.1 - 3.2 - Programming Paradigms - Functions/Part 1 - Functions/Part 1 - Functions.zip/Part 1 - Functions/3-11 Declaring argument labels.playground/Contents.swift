func double(years number: Int) -> Int {
   number * 2
}
let result = double(years: 8)
let message = "The result is \(result)"  // "The results is 16"
