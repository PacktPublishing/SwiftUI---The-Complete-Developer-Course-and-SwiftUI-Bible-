func multiply(number1: Int, number2: Int) {
   let result = number1 * number2
   let message = "The result is \(result)"  // "The result is 80"
}
multiply(number1: 20, number2: 4)
