let absolutenumber = abs(-25)
let minnumber = min(absolutenumber, 100)
print("The number is: \(minnumber)")  // "The number is: 25"
