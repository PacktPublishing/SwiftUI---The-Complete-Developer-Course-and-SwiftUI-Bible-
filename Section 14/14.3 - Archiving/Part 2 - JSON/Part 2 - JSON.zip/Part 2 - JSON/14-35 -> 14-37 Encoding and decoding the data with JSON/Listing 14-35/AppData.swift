
import SwiftUI

struct Book: Codable {
   var title: String
   var author: String
   var year: Int
   var cover: String?
}
struct BookViewModel: Identifiable {
   let id: UUID = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var year: String {
      return String(book.year)
   }
   var cover: UIImage {
      if let imageName = book.cover {
         let manager = FileManager.default
         let docURL = manager.urls(for: .documentDirectory, in: .userDomainMask).first!
         let imageURL = docURL.appendingPathComponent(imageName)
         if let coverImage = UIImage(contentsOfFile: imageURL.path) {
            return coverImage
         }
      }
      return UIImage(named: "nopicture")!
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []
   var manager: FileManager
   var docURL: URL

   func saveBook(book: Book) {
      userData.append(BookViewModel(book: book))
      saveModel()
   }
   func saveModel() {
      let list = userData.map({ value in
         return value.book
      })
      let filePath = docURL.appendingPathComponent("userdata.dat").path
      let encoder = JSONEncoder()
      if let data = try? encoder.encode(list) {
         manager.createFile(atPath: filePath, contents: data, attributes: nil)
      }
   }
   func storeCover() -> String? {
      let placeholder = UIImage(named: "bookcover")
      let imageName = "image-\(UUID()).dat"
      if let imageData = placeholder?.pngData() {
         let fileURL = docURL.appendingPathComponent(imageName)
         if manager.createFile(atPath: fileURL.path, contents: imageData, attributes: nil) {
            return imageName
         }
      }
      return nil
   }
   init() {
      manager = FileManager.default
      docURL = manager.urls(for: .documentDirectory, in: .userDomainMask).first!

      let filePath = docURL.appendingPathComponent("userdata.dat").path
      if manager.fileExists(atPath: filePath) {
         if let content = manager.contents(atPath: filePath) {
            let decoder = JSONDecoder()
            if let list = try? decoder.decode([Book].self, from: content) {
               userData = list.map({ value in
                  return BookViewModel(book: value)
               })
            }
         }
      }
   }
}

