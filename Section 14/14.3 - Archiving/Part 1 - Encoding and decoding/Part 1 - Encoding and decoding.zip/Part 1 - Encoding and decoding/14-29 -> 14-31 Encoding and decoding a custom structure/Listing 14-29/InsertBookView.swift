
import SwiftUI

struct InsertBookView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool
   @State private var inputTitle: String = ""
   @State private var inputAuthor: String = ""
   @State private var inputYear: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Title:")
            TextField("Insert Title", text: $inputTitle)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Author:")
            TextField("Insert Author", text: $inputAuthor)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Year:")
            TextField("Insert Year", text: $inputYear)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let newTitle = self.inputTitle.trimmingCharacters(in: .whitespaces)
               let newAuthor = self.inputAuthor.trimmingCharacters(in: .whitespaces)
               let newYear = Int(self.inputYear)
               if !newTitle.isEmpty && !newAuthor.isEmpty && newYear != nil {
                  let coverName = self.appData.storeCover()
                  self.appData.saveBook(book: Book(title: newTitle, author: newAuthor, year: newYear!, cover: coverName))
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}

struct InsertBookView_Previews: PreviewProvider {
    static var previews: some View {
        InsertBookView(openSheet: .constant(false))
            .environmentObject(AppData())
    }
}
