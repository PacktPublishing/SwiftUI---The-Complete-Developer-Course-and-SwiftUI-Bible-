
import SwiftUI

class AppData: ObservableObject {
   @Published var counter: Double = UserDefaults.standard.double(forKey: "counter") {
      didSet {
         UserDefaults.standard.set(counter, forKey: "counter")
      }
   }
}
