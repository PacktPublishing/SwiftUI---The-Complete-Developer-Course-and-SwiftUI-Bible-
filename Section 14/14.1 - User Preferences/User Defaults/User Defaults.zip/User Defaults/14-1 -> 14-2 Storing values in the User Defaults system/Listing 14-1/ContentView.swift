
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      HStack {
         Stepper("", value: self.$appData.counter)
            .labelsHidden()
         Text("\(self.appData.counter, specifier: "%.2f")")
            .font(.title)
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
