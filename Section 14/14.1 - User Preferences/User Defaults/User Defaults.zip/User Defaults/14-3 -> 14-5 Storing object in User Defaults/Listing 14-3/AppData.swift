
import SwiftUI

class AppData: ObservableObject {
   @Published var lastDate: Date {
      didSet {
         UserDefaults.standard.set(lastDate, forKey: "lastDate")
      }
   }
   var interval: String {
      let calendar = Calendar.current
      let components = calendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: lastDate, to: Date())
      let message = "You haven't use this app in \(components.year!) years, \(components.month!) months, \(components.day!) days, \(components.hour!) hours, \(components.minute!) minutes, \(components.second!) seconds"
      return message
   }
   init() {
      if let date = UserDefaults.standard.object(forKey: "lastDate") as? Date {
         self.lastDate = date
      } else {
         self.lastDate = Date()
      }
   }
}
