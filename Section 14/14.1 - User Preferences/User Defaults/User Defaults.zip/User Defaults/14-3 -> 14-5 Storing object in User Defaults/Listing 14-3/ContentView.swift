
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      HStack {
         Text("\(self.appData.interval)")
            .lineLimit(nil)
            .padding()
      }
   }
}

