
import SwiftUI
import CoreData

struct ContentView: View {
   @FetchRequest(entity: Books.entity(), sortDescriptors: []) var listOfBooks: FetchedResults<Books>

   var body: some View {
      NavigationView {
         List {
            ForEach(listOfBooks, id: \.self) { book in
               RowBook(book: book)
            }
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink(destination: InsertBookView(), label: {
            Text("Add Book")
         }))
      }
   }
}
struct RowBook: View {
   let book: Books

   var imageCover: UIImage {
      if let data = book.thumbnail, let image = UIImage(data: data) {
         return image
      } else {
         return UIImage(named: "nopicture")!
      }
   }
   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: imageCover)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.title ?? "Undefined").bold()
            Text(book.author?.name ?? "Undefined")
            Text(String(book.year)).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView()
         .environment(\.managedObjectContext, dbContext)
   }
}
