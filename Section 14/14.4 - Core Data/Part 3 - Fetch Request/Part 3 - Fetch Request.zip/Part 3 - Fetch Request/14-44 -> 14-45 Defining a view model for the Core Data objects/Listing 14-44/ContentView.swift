
import SwiftUI
import CoreData

struct ContentView: View {
   @FetchRequest(entity: Books.entity(), sortDescriptors: []) var listOfBooks: FetchedResults<Books>

   var body: some View {
      NavigationView {
         List {
            ForEach(listOfBooks, id: \.self) { book in
               RowBook(book: book)
            }
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink(destination: InsertBookView(), label: {
            Text("Add Book")
         }))
      }
   }
}
struct RowBook: View {
   let book: Books

   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: book.showThumbnail)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.showTitle).bold()
            Text(book.showAuthor)
            Text(book.showYear).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView()
         .environment(\.managedObjectContext, dbContext)
   }
}
