
import SwiftUI
import CoreData

struct InsertBookView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Environment(\.presentationMode) var presentation

   @State private var selectedAuthor: Authors? = nil
   @State private var inputTitle: String = ""
   @State private var inputYear: String = ""

   var body: some View {
      VStack(spacing: 12) {
         HStack {
            Text("Title:")
            TextField("Insert Title", text: $inputTitle)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Text("Year:")
            TextField("Insert Year", text: $inputYear)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack(alignment: .top) {
            Text("Author:")
            VStack(alignment: .leading, spacing: 8) {
               Text(self.selectedAuthor?.name ?? "Undefined")
                  .foregroundColor(self.selectedAuthor != nil ? Color.black : Color.gray)
               NavigationLink(destination: AuthorsView(selected: self.$selectedAuthor), label: {
                  Text("Select Author")
               })
            }
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
         Spacer()
      }.padding()
      .navigationBarTitle("Add Book")
      .navigationBarItems(trailing: Button("Save") {
         let newTitle = self.inputTitle.trimmingCharacters(in: .whitespaces)
         let newYear = Int32(self.inputYear)
         if !newTitle.isEmpty && newYear != nil {
            let newBook = Books(context: self.dbContext)
            newBook.title = newTitle
            newBook.year = newYear!
            newBook.author = self.selectedAuthor
            newBook.cover = UIImage(named: "bookcover")?.pngData()
            newBook.thumbnail = UIImage(named: "bookthumbnail")?.pngData()
                      
            let firstLetter = String(newTitle[newTitle.startIndex]).uppercased()
            let request: NSFetchRequest<SortLetters> = SortLetters.fetchRequest()
            request.predicate = NSPredicate(format: "letter = %@", firstLetter)
            if let list = try? self.dbContext.fetch(request), list.count > 0 {
               let oldLetter = list[0]
               newBook.sortletter = oldLetter
            } else {
               let newLetter = SortLetters(context: self.dbContext)
               newLetter.letter = firstLetter
               newBook.sortletter = newLetter
            }
            do {
               try self.dbContext.save()
               self.presentation.wrappedValue.dismiss()
            } catch {
               print("Error saving record")
            }
         }
      })
   }
}
struct InsertBookView_Previews: PreviewProvider {
    static var previews: some View {
        InsertBookView()
    }
}
