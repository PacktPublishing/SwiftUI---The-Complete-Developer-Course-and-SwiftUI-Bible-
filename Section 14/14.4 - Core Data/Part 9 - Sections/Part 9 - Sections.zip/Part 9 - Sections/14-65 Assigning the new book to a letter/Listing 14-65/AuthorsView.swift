
import SwiftUI

struct AuthorsView: View {
   @Environment(\.presentationMode) var presentation
   @FetchRequest(entity: Authors.entity(), sortDescriptors: []) var listOfAuthors: FetchedResults<Authors>
   @Binding var selected: Authors?

   var body: some View {
      List {
         ForEach(listOfAuthors, id: \.self) { author in
            HStack {
               Text(author.showName)
               Spacer()
               Text(String(author.books?.count ?? 0))
            }
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .leading)
            .contentShape(Rectangle())
            .onTapGesture {
               self.selected = author
               self.presentation.wrappedValue.dismiss()
            }
         }
      }
      .navigationBarTitle("Authors")
      .navigationBarItems(trailing: NavigationLink(destination: InsertAuthorView(), label: {
         Text("Add Author")
      }))
   }
}
struct AuthorsView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return AuthorsView(selected: .constant(nil))
         .environment(\.managedObjectContext, dbContext)
   }
}
