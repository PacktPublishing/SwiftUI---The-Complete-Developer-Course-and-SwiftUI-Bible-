
import SwiftUI
import CoreData

struct ContentView: View {
   @Environment(\.managedObjectContext) var dbContext
   @FetchRequest(entity: SortLetters.entity(), sortDescriptors: [NSSortDescriptor(key: "letter", ascending: true)]) var listOfLetters: FetchedResults<SortLetters>

   var body: some View {
      NavigationView {
         List {
            ForEach(listOfLetters, id: \.self) { sort in
               Section(header: Text(sort.letter ?? "")) {
                  ForEach(sort.listBooks, id: \.self) { book in
                     RowBook(book: book)
                  }
                  .onDelete(perform: { indexes in
                     self.deleteBook(indexes: indexes, letter: sort)
                  })
               }
            }
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink(destination: InsertBookView(), label: {
            Text("Add Book")
         }))
      }
   }
   func deleteBook(indexes: IndexSet, letter: SortLetters) {
      let listBooks = letter.listBooks
      for index in indexes {
         let book = listBooks[index]
         self.dbContext.delete(book)
      }
      do {
         try self.dbContext.save()
         if letter.listBooks.count <= 0 {
            self.dbContext.delete(letter)
            try self.dbContext.save()
         }
      } catch {
         print("Error deleting objects")
      }
   }
}
struct RowBook: View {
   let book: Books

   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: book.showThumbnail)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.showTitle).bold()
            Text(book.showAuthor)
            Text(book.showYear).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView()
         .environment(\.managedObjectContext, dbContext)
   }
}
