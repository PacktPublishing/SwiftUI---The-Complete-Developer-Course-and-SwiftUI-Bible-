
import SwiftUI
import CoreData

class ContentData: ObservableObject {
   @Published var search: String? = nil
   @Published var searchInput: String = "" {
      didSet {
         setSearch(term: searchInput)
      }
   }
   func setSearch(term: String) {
      let toSearch = term.trimmingCharacters(in: .whitespaces)
      search = toSearch == "" ? nil : toSearch
   }
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()

   var body: some View {
      NavigationView {
         VStack {
            HStack {
               TextField("Insert Search", text: $contentData.searchInput, onCommit: {
                  self.contentData.setSearch(term: self.contentData.searchInput)
               }).textFieldStyle(RoundedBorderTextFieldStyle())
               Button("🔎") {
                  self.contentData.setSearch(term: self.contentData.searchInput)
               }
            }.padding()
            ListBooksView(search: contentData.search)
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink(destination: InsertBookView(), label: {
            Text("Add Book")
         }))
      }
   }
}
struct ListBooksView: View {
   @Environment(\.managedObjectContext) var dbContext
   @FetchRequest(entity: Books.entity(), sortDescriptors: [NSSortDescriptor(key: "title", ascending: true)]) var listOfBooks: FetchedResults<Books>
   @State private var totalBooks: Int = 0

   init(search: String?) {
      if let term = search {
         self._listOfBooks = FetchRequest(entity: Books.entity(), sortDescriptors: [NSSortDescriptor(key: "title", ascending: true)], predicate: NSPredicate(format: "title CONTAINS[dc] %@", term))
      }
   }
   var body: some View {
      List {
         HStack {
            Text("Total Books")
            Spacer()
            Text(String(totalBooks)).bold()
         }.foregroundColor(Color.green)

         ForEach(listOfBooks, id: \.self) { book in
            NavigationLink(destination: ModifyBookView(book: book), label: {
               RowBook(book: book)
                  .id(UUID())
            })
         }
         .onDelete(perform: { indexes in
            for index in indexes {
               self.dbContext.delete(self.listOfBooks[index])
               self.countBooks()
            }
            do {
               try self.dbContext.save()
            } catch {
               print("Error deleting objects")
            }
         })
      }
      .onAppear(perform: {
         self.countBooks()
      })
   }
   func countBooks() {
      let request: NSFetchRequest<Books> = Books.fetchRequest()
      if let list = try? self.dbContext.fetch(request) {
         let count = list.count
         self.totalBooks = count
      }
   }

//    func countBooks() {
//       let request: NSFetchRequest<Books> = Books.fetchRequest()
//       if let count = try? self.dbContext.count(for: request) {
//          self.totalBooks = count
//       }
//    }

}
struct RowBook: View {
   let book: Books

   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: book.showThumbnail)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.showTitle).bold()
            Text(book.showAuthor)
            Text(book.showYear).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView()
         .environment(\.managedObjectContext, dbContext)
   }
}
