
import SwiftUI
import CoreData

class ContentData: ObservableObject {
   @Published var search: String? = nil
   @Published var searchInput: String = "" {
      didSet {
         setSearch(term: searchInput)
      }
   }
   func setSearch(term: String) {
      let toSearch = term.trimmingCharacters(in: .whitespaces)
      search = toSearch == "" ? nil : toSearch
   }
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()

   var body: some View {
      NavigationView {
         VStack {
            HStack {
               TextField("Insert Search", text: $contentData.searchInput, onCommit: {
                  self.contentData.setSearch(term: self.contentData.searchInput)
               }).textFieldStyle(RoundedBorderTextFieldStyle())
               Button("🔎") {
                  self.contentData.setSearch(term: self.contentData.searchInput)
               }
            }.padding()
            ListBooksView(search: contentData.search)
         }
         .navigationBarTitle("Books")
         .navigationBarItems(trailing: NavigationLink(destination: InsertBookView(), label: {
            Text("Add Book")
         }))
      }
   }
}
struct ListBooksView: View {
   @Environment(\.managedObjectContext) var dbContext
   @FetchRequest(entity: Books.entity(), sortDescriptors: [NSSortDescriptor(key: "title", ascending: true)]) var listOfBooks: FetchedResults<Books>

   init(search: String?) {
      if let term = search {
         self._listOfBooks = FetchRequest(entity: Books.entity(), sortDescriptors: [NSSortDescriptor(key: "title", ascending: true)], predicate: NSPredicate(format: "title CONTAINS[dc] %@", term))
      }
   }
   var body: some View {
      List {
         ForEach(listOfBooks, id: \.self) { book in
            RowBook(book: book)
         }
         .onDelete(perform: { indexes in
            for index in indexes {
               self.dbContext.delete(self.listOfBooks[index])
            }
            do {
               try self.dbContext.save()
            } catch {
               print("Error deleting objects")
            }
         })
      }
   }
}
struct RowBook: View {
   let book: Books

   var body: some View {
      HStack(alignment: .top) {
         Image(uiImage: book.showThumbnail)
            .resizable()
            .scaledToFit()
            .frame(width: 80, height: 100)
            .cornerRadius(10)
         VStack(alignment: .leading, spacing: 2) {
            Text(book.showTitle).bold()
            Text(book.showAuthor)
            Text(book.showYear).font(.caption)
            Spacer()
         }.padding(.top, 5)
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView()
         .environment(\.managedObjectContext, dbContext)
   }
}
