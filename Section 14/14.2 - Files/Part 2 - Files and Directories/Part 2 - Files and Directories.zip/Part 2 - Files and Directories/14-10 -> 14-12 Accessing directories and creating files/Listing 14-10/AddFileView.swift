
import SwiftUI

struct AddFileView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool
   @State private var nameInput: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Name:")
            TextField("Insert File Name", text: $nameInput)
               .textFieldStyle(RoundedBorderTextFieldStyle())
               .autocapitalization(.none)
               .disableAutocorrection(true)
         }.padding(.top, 25)
         HStack {
            Spacer()
            Button("Create") {
               var fileName = self.nameInput.trimmingCharacters(in: .whitespaces)
               if !fileName.isEmpty {
                  fileName += ".txt"
                  self.appData.saveFile(name: fileName)
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}
struct AddFileView_Previews: PreviewProvider {
    static var previews: some View {
        AddFileView(openSheet: .constant(false))
            .environmentObject(AppData())
    }
}
