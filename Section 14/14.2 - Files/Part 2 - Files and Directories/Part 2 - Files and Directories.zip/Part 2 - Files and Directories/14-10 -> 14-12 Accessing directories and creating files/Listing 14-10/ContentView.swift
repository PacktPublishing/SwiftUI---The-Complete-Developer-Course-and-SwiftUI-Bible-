
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         VStack {
            Text("No Files")
            Spacer()
         }.padding()
         .navigationBarTitle("Files")
         .navigationBarItems(trailing: Button("Add File") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            AddFileView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
