
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         VStack {
            Picker("", selection: self.$appData.currentDirectory) {
               ForEach(0..<self.appData.directories.count) { index in
                  Text(self.appData.directories[index]).tag(index)
               }
            }.padding([.leading, .trailing], 8)
            .labelsHidden()
            .pickerStyle(SegmentedPickerStyle())

            List {
               ForEach(self.appData.listOfFiles[self.appData.currentDirectory] ?? []) { file in
                  Text(file.name)
               }
            }
         }
         .navigationBarTitle("Files")
         .navigationBarItems(trailing: Button("Add File") {
            self.openSheet = true
         }.disabled(self.appData.currentDirectory != 0 ? true : false))
         .sheet(isPresented: $openSheet) {
            AddFileView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
