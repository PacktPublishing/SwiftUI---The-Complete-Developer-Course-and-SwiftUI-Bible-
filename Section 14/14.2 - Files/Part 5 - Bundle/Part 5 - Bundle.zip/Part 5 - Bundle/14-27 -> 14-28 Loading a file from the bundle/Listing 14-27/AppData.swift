
import SwiftUI

class AppData: ObservableObject {
   @Published var textInFile: String = "Undefined"

   init() {
      let bundle = Bundle.main
      if let filePath = bundle.path(forResource: "quote", ofType: "txt") {
         let manager = FileManager.default
         if let data = manager.contents(atPath: filePath) {
            if let message = String(data: data, encoding: .utf8) {
               textInFile = message
            }
         }
      } else {
         print("File not found")
      }
   }
}
