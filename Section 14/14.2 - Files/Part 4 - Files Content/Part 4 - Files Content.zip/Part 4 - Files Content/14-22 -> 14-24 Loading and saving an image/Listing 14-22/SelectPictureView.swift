
import SwiftUI

struct SelectPictureView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool

   var body: some View {
      VStack {
         ScrollView(.horizontal, showsIndicators: true) {
            HStack(spacing: 15) {
               ForEach(self.appData.listPictures, id: \.self) { name in
                  ZStack(alignment: .bottom) {
                     Image(name)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 160)
                     Button(action: {
                        self.appData.saveFile(namePicture: name)
                        self.openSheet = false
                     }, label: {
                        Text("Select Picture")
                           .foregroundColor(Color.white)
                     }).padding(8)
                     .background(Color.blue)
                     .cornerRadius(5)
                     .offset(x: 0, y: -15)
                  }
               }
            }
         }.padding(.top, 25)
         Spacer()
      }.padding()
   }
}

struct SelectPictureView_Previews: PreviewProvider {
    static var previews: some View {
        SelectPictureView(openSheet: .constant(false))
            .environmentObject(AppData())
    }
}
