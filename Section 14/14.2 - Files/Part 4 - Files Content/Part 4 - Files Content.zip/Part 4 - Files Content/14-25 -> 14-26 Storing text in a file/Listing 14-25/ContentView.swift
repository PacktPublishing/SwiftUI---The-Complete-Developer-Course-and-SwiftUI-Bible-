
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var inputText: String = ""

   var body: some View {
      VStack(spacing: 12) {
         Text(appData.textInFile)
            .lineLimit(nil)
            .padding(15)
            .frame(minWidth: 0, maxWidth: .infinity)
            .background(Color(white: 0.8))
         TextField("Insert New Message", text: $inputText)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         HStack {
            Spacer()
            Button("Save Message") {
               let message = self.inputText.trimmingCharacters(in: .whitespaces)
               if !message.isEmpty {
                  self.appData.saveFile(text: message)
                  self.inputText = ""
               }
            }
         }
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(AppData())
    }
}
