
import SwiftUI

struct ContentView: View {
   var body: some View {
      NavigationView {
         List {
            Text("Hello World")
         }
         .navigationBarTitle("Test Bar")
      }
      .onAppear(perform: {
         let appearance = UINavigationBarAppearance()
         appearance.backgroundColor = UIColor.green

         let barAppearance = UINavigationBar.appearance()
         barAppearance.standardAppearance = appearance
         barAppearance.compactAppearance = appearance
         barAppearance.scrollEdgeAppearance = appearance
      })
   }
}

