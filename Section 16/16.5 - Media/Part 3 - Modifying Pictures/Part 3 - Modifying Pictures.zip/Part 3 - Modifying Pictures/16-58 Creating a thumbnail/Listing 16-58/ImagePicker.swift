
import SwiftUI

struct ImagePicker: UIViewControllerRepresentable {
   @Binding var showAlert: Bool
   @Binding var openImagePicker: Bool
   @Binding var picture: UIImage?

   func makeUIViewController(context: Context) -> UIImagePickerController {
      let mediaPicker = UIImagePickerController()
      mediaPicker.delegate = context.coordinator
      if UIImagePickerController.isSourceTypeAvailable(.camera) {
         mediaPicker.sourceType = .camera
      } else {
         print("The media is not available")
      }
      return mediaPicker
   }
   func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
   func makeCoordinator() -> ImagePickerCoordinator {
      ImagePickerCoordinator(alert: $showAlert, open: $openImagePicker, picture: $picture)
   }
}
class ImagePickerCoordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
   var showAlert: Binding<Bool>
   var openImagePicker: Binding<Bool>
   var picture: Binding<UIImage?>

   init(alert: Binding<Bool>, open: Binding<Bool>, picture: Binding<UIImage?>) {
      self.showAlert = alert
      self.openImagePicker = open
      self.picture = picture
   }
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
      if let newpicture = info[.originalImage] as? UIImage {
         let scale = UIScreen.main.scale
         let maximum: CGFloat = 80
         var width = newpicture.size.width / scale
         var height = newpicture.size.height / scale
              
         if width > height {
            height = height * maximum / width
            width = maximum
         } else {
            width = width * maximum / height
            height = maximum
         }
         let render = UIGraphicsImageRenderer(size: CGSize(width: width, height: height))
         render.image(actions: { (renderContext) in
            let context = renderContext.cgContext
            UIGraphicsPushContext(context)
            newpicture.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
            self.picture.wrappedValue = renderContext.currentImage
         })
         self.openImagePicker.wrappedValue = false
      }
   }
}
