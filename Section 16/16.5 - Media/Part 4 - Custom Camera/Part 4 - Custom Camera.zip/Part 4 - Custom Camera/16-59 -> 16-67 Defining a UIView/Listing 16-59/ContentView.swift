
import SwiftUI

struct ContentView: View {
   @State private var openCamera: Bool = false
   @State private var picture: UIImage?

   var body: some View {
      NavigationView {
         VStack {
            HStack {
               Spacer()
               NavigationLink(destination: CustomCameraView(openCamera: $openCamera, picture: $picture), isActive: $openCamera, label: { Text("Take Picture") })
            }
            Image(uiImage: picture ?? UIImage(named: "nopicture")!)
               .resizable()
               .scaledToFill()
               .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
               .clipped()
            Spacer()
         }.padding()
         .navigationBarTitle("")
         .navigationBarHidden(true)
      }.statusBar(hidden: true)
   }
}
