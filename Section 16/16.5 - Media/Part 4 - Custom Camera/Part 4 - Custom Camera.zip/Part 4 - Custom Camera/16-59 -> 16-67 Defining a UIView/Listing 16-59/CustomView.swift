
import SwiftUI
import AVFoundation

class ViewData {
   var captureSession: AVCaptureSession!
   var stillImage: AVCapturePhotoOutput!
   var previewLayer: AVCaptureVideoPreviewLayer!
   var imageOrientation: UIImage.Orientation!
   var coordinator: ViewCoordinator!
}
struct CustomView: UIViewRepresentable {
   @Binding var openCamera: Bool
   @Binding var picture: UIImage?
   var viewData = ViewData()
   let view = UIView()

   init(openCamera: Binding<Bool>, picture: Binding<UIImage?>) {
      self._openCamera = openCamera
      self._picture = picture
   }
   func makeUIView(context: Context) -> UIView {
      return view
   }
   func updateUIView(_ uiView: UIView, context: Context) {
      let main = OperationQueue.main
      main.addOperation {
         if self.viewData.captureSession != nil {
            self.viewData.previewLayer?.frame = self.view.bounds
            let connection = self.viewData.previewLayer.connection
            connection?.videoOrientation = self.getCurrentOrientation()
         }
      }
   }
   func getAuthorization() {
      let status = AVCaptureDevice.authorizationStatus(for: .video)
      if status == .authorized {
         let main = OperationQueue.main
         main.addOperation({
            self.prepareCamera()
         })
      } else if status == .notDetermined {
         AVCaptureDevice.requestAccess(for: .video, completionHandler: { (granted: Bool) in
            let main = OperationQueue.main
            main.addOperation({
               if granted {
                  self.prepareCamera()
               } else {
                  print("Not Authorized")
               }
            })
         })
      } else {
         print("Not Authorized")
      }
   }
    func prepareCamera() {
       viewData.captureSession = AVCaptureSession()
       viewData.captureSession.sessionPreset = .photo
    
       if let device = AVCaptureDevice.default(for: AVMediaType.video) {
          if let input = try? AVCaptureDeviceInput(device: device) {
             viewData.captureSession.addInput(input)
             viewData.stillImage = AVCapturePhotoOutput()
             viewData.captureSession.addOutput(viewData.stillImage)
             self.showCamera()
          } else {
             print("Not Authorized")
          }
       } else {
          print("Not Authorized")
       }
    }
    func showCamera() {
       let width = view.bounds.size.width
       let height = view.bounds.size.height
    
       viewData.previewLayer = AVCaptureVideoPreviewLayer(session: viewData.captureSession)
       viewData.previewLayer.videoGravity = .resizeAspectFill
       viewData.previewLayer.frame = CGRect(x: 0, y: 0, width: width, height: height)
        
       let connection = viewData.previewLayer.connection
       connection?.videoOrientation = getCurrentOrientation()
        
       let layer = view.layer
       layer.addSublayer(viewData.previewLayer)
       viewData.captureSession.startRunning()
    }
    func getCurrentOrientation() -> AVCaptureVideoOrientation {
       var orientation: AVCaptureVideoOrientation = .portrait
       let device = UIDevice.current
       switch device.orientation {
          case .portrait:
             orientation = .portrait
             viewData.imageOrientation = .right
          case .landscapeRight:
             orientation = .landscapeLeft
             viewData.imageOrientation = .down
          case .landscapeLeft:
             orientation = .landscapeRight
             viewData.imageOrientation = .up
          default:
             break
       }
       return orientation
    }
    func takePicture() {
       let settings = AVCapturePhotoSettings()
       viewData.stillImage.capturePhoto(with: settings, delegate: viewData.coordinator)
    }
    func makeCoordinator() -> ViewCoordinator {
       viewData.coordinator = ViewCoordinator(picture: $picture, open: $openCamera, viewData: viewData)
       return viewData.coordinator
    }
}
class ViewCoordinator: NSObject, AVCapturePhotoCaptureDelegate {
   var picture: Binding<UIImage?>
   var openCamera: Binding<Bool>
   var viewData: ViewData
    
   init(picture: Binding<UIImage?>, open: Binding<Bool>, viewData: ViewData) {
      self.picture = picture
      self.openCamera = open
      self.viewData = viewData
   }
   func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
      let scale = UIScreen.main.scale
      if let imageData = photo.fileDataRepresentation() {
         self.picture.wrappedValue = UIImage(data: imageData, scale: scale)
         self.openCamera.wrappedValue = false
      }
   }
}
