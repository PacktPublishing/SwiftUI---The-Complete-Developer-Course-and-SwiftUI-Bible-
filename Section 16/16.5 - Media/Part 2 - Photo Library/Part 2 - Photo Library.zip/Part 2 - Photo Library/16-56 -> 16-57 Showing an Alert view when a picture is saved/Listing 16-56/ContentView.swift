
import SwiftUI

class ContentData: ObservableObject {
   @Published var showAlert: Bool = false
   @Published var openImagePicker: Bool = false
   @Published var picture: UIImage?
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()
   var imagePicker: ImagePicker!

   init() {
      imagePicker = ImagePicker(showAlert: $contentData.showAlert, openImagePicker: $contentData.openImagePicker, picture: $contentData.picture)
   }
   var body: some View {
      NavigationView {
         VStack {
            HStack {
               Spacer()
               NavigationLink(
                  destination: imagePicker
                     .navigationBarTitle("")
                     .navigationBarHidden(true)
                     .edgesIgnoringSafeArea(.all),
                  isActive: $contentData.openImagePicker, label: {
                     Text("Get Picture")
                  })
            }
            Image(uiImage: contentData.picture ?? UIImage(named: "nopicture")!)
               .resizable()
               .scaledToFill()
               .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
               .clipped()
            Spacer()
         }.padding()
         .navigationBarTitle("")
         .navigationBarHidden(true)
         .alert(isPresented: $contentData.showAlert) {
            Alert(title: Text("Picture Saved"), message: Text("The picture was added to your photos"), dismissButton: .default(Text("OK")))
         }
      }.statusBar(hidden: true)
   }
}
