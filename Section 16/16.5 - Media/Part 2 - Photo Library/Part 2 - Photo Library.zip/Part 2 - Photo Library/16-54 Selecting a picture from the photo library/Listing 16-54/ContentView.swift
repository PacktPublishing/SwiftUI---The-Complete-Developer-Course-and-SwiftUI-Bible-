
import SwiftUI

class ContentData: ObservableObject {
   @Published var openImagePicker: Bool = false
   @Published var picture: UIImage?
}
struct ContentView: View {
   @ObservedObject var contentData = ContentData()
   var imagePicker: ImagePicker!

   init() {
   imagePicker = ImagePicker(openImagePicker: self.$contentData.openImagePicker, picture: self.$contentData.picture)
   }
   var body: some View {
      NavigationView {
         VStack {
            HStack {
               Spacer()
               NavigationLink(
                  destination: imagePicker
                     .navigationBarTitle("")
                     .navigationBarHidden(true)
                     .edgesIgnoringSafeArea(.all),
                  isActive: $contentData.openImagePicker, label: {
                     Text("Get Picture")
                  })
            }
            Image(uiImage: contentData.picture ?? UIImage(named: "nopicture")!)
               .resizable()
               .scaledToFill()
               .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
               .clipped()
            Spacer()
         }.padding()
         .navigationBarTitle("")
         .navigationBarHidden(true)
      }.statusBar(hidden: true)
   }
}
