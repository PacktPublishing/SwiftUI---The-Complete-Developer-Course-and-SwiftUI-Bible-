
import SwiftUI

struct ImagePicker: UIViewControllerRepresentable {
   @Binding var openImagePicker: Bool
   @Binding var picture: UIImage?

   func makeUIViewController(context: Context) -> UIImagePickerController {
      let mediaPicker = UIImagePickerController()
      mediaPicker.delegate = context.coordinator
      if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
         mediaPicker.sourceType = .photoLibrary
         mediaPicker.mediaTypes = ["public.image", "public.movie"]
      } else {
         print("The media is not available")
      }
      return mediaPicker
   }
   func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
   func makeCoordinator() -> ImagePickerCoordinator {
      ImagePickerCoordinator(open: $openImagePicker, picture: $picture)
   }
}
class ImagePickerCoordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
   var openImagePicker: Binding<Bool>
   var picture: Binding<UIImage?>

   init(open: Binding<Bool>, picture: Binding<UIImage?>) {
      self.openImagePicker = open
      self.picture = picture
   }
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
      let media = info[.mediaType] as! String
      if media == "public.image" {
         if let newpicture = info[.originalImage] as? UIImage {
            self.picture.wrappedValue = newpicture
         }
      }
      self.openImagePicker.wrappedValue = false
   }
   func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
      self.openImagePicker.wrappedValue = false
   }
}
