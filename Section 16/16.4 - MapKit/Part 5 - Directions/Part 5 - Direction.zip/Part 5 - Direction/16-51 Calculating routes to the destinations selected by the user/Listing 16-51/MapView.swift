
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   var map = MKMapView()

   func makeUIView(context: Context) -> MKMapView {
      map.mapType = .standard
      map.delegate = context.coordinator
      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
    
   func showHome() {
      let appleCoord = CLLocationCoordinate2D(latitude: 40.7637825011971, longitude: -73.9731328627541)
      let region = MKCoordinateRegion(center: appleCoord, latitudinalMeters: 2000, longitudinalMeters: 2000)
      map.setRegion(region, animated: false)
          
      let request = MKLocalSearch.Request()
      request.naturalLanguageQuery = "Coffee"
      request.region = region

      let search = MKLocalSearch(request: request)
      search.start(completionHandler: { (results, error) in
         if let items = results?.mapItems {
            for item in items {
               if let coordinates = item.placemark.location?.coordinate {
                  let annotation = MKPointAnnotation()
                  annotation.coordinate = coordinates
                  annotation.title = item.name
                  annotation.subtitle = item.phoneNumber
                  self.map.addAnnotation(annotation)
               }
            }
         }
      })
   }
   func makeCoordinator() -> MapViewCoordinator {
      return MapViewCoordinator(map: map)
   }
}
class MapViewCoordinator: NSObject, MKMapViewDelegate {
   var map: MKMapView
   var route: MKRoute?

   init(map: MKMapView) {
      self.map = map
   }
   func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
      if let destinationCoord = view.annotation?.coordinate {
         let appleCoord = CLLocationCoordinate2D(latitude: 40.7637825011971, longitude: -73.9731328627541)
         let placeOrigin = MKPlacemark(coordinate: appleCoord)
         let origin = MKMapItem(placemark: placeOrigin)
         origin.name = "Apple Store"
              
         let placeDestination = MKPlacemark(coordinate: destinationCoord)
         let destination = MKMapItem(placemark: placeDestination)
         destination.name = view.annotation?.title!
              
         let request = MKDirections.Request()
         request.source = origin
         request.destination = destination
         request.transportType = .walking
         request.requestsAlternateRoutes = false
              
         let directions = MKDirections(request: request)
         directions.calculate(completionHandler: { (results, error) in
            if let routes = results?.routes {
               if let oldRoute = self.route {
                  self.map.removeOverlay(oldRoute.polyline)
                  self.route = nil
               }
               self.route = routes.first!
               self.map.addOverlay(self.route!.polyline, level: .aboveRoads)
            }
         })
      }
   }
   func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
      let render = MKPolylineRenderer(overlay: overlay)
      render.strokeColor = UIColor.red
      return render
   }
}
