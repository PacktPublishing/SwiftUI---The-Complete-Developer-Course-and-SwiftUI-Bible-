
import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
   var map = MKMapView()
   var locationManager: CLLocationManager!

   init() {
      locationManager = CLLocationManager()
      locationManager.requestWhenInUseAuthorization()
   }
   func makeUIView(context: Context) -> MKMapView {
      map.mapType = .standard
      map.isRotateEnabled = false
      map.showsUserLocation = true
      map.userLocation.title = "You are here"
      map.delegate = context.coordinator
      return map
   }
   func updateUIView(_ uiView: MKMapView, context: Context) {}
    
   func showHome() {
      let location = map.userLocation
      let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 1000, longitudinalMeters: 1000)
      map.setRegion(region, animated: true)
   }
    
    func makeCoordinator() ->MapViewCoordinator {
        return MapViewCoordinator(map: map)
    }
}

class MapViewCoordinator: NSObject, MKMapViewDelegate {
    let map: MKMapView
    init(map: MKMapView) {
        self.map = map
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        map.setCenter(userLocation.coordinate, animated: true)
    }
}
