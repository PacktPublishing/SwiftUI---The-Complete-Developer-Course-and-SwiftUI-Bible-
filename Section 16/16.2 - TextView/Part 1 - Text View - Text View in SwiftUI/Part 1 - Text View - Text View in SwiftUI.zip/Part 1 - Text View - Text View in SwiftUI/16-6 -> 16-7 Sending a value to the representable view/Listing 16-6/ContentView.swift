
import SwiftUI

struct ContentView: View {
   @State private var inputText: String = "There is a wide, yawning black infinity. In every direction, the extension is endless; the sensation of depth is overwhelming. And the darkness is immortal. Where light exists, it is pure, blazing, fierce; but light exists almost nowhere, and the blackness itself is also pure and blazing and fierce. Carl Sagan"

   var body: some View {
      VStack {
         TextView(input: $inputText)
      }.padding()
   }
}
