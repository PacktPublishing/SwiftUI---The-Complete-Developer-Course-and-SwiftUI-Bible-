
import SwiftUI

struct FileContent: Codable {
   var text: String
}
class AppData: ObservableObject {
   @Published var fileContent = FileContent(text: "") {
      didSet {
         self.saveFile()
      }
   }
   let manager: FileManager
   let fileURL: URL

   init() {
      manager = FileManager.default
      let documents = manager.urls(for: .documentDirectory, in: .userDomainMask).first!
      fileURL = documents.appendingPathComponent("userdata.dat")

      if manager.fileExists(atPath: fileURL.path) {
         if let data = manager.contents(atPath: fileURL.path) {
            let decoder = JSONDecoder()
            if let content = try? decoder.decode(FileContent.self, from: data) {
               self.fileContent = content
            }
         }
      }
   }
   func saveFile() {
      let encoder = JSONEncoder()
      if let data = try? encoder.encode(self.fileContent) {
         manager.createFile(atPath: fileURL.path, contents: data, attributes: nil)
      }
   }
}
