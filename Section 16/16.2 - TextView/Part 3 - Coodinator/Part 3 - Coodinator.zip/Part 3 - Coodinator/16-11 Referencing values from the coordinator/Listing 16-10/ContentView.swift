
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         TextView(input: $appData.fileContent.text)
      }.padding(10)
   }
}
