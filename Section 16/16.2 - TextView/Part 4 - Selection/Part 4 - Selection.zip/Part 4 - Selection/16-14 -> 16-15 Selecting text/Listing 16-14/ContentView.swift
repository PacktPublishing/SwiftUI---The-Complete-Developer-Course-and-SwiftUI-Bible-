
import SwiftUI

struct ContentView: View {
   @State private var selectedText: String = ""

   var body: some View {
      VStack {
         Text("Selection: \(selectedText)")
            .lineLimit(1)
         TextView(selected: $selectedText)
      }.padding()
   }
}
