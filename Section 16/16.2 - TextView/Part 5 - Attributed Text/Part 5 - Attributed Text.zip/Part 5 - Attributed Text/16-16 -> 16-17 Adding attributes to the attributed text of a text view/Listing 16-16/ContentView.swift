
import SwiftUI

struct ContentView: View {
   let textView = TextView()

   var body: some View {
      VStack {
         Button("Modify") {
            self.textView.changeAttributes()
         }
         textView
      }.padding()
   }
}
