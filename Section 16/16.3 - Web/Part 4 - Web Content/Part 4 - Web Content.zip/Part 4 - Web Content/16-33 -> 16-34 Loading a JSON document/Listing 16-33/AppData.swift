
import SwiftUI
import Combine

struct Post: Codable, Identifiable {
   var id: Int
   var userId: Int
   var title: String
   var body: String
}
class AppData: ObservableObject {
   @Published var listOfPosts: [Post] = []

   var publisherWeb: AnyCancellable?

   init() {
      let webURL = URL(string: "https://jsonplaceholder.typicode.com/posts")
      let request = URLRequest(url: webURL!)

      let session = URLSession.shared

      publisherWeb = session.dataTaskPublisher(for: request)
         .tryMap({ data, response -> Data? in
            if let resp = response as? HTTPURLResponse {
               if resp.statusCode == 200 {
                  return data
               }
            }
            return nil
         })
         .assertNoFailure()
         .receive(on: RunLoop.main)
         .sink(receiveValue: { data in
            let decoder = JSONDecoder()
            if let webData = data, let posts = try? decoder.decode([Post].self, from: webData) {
               self.listOfPosts = posts
            }
         })
   }
}
