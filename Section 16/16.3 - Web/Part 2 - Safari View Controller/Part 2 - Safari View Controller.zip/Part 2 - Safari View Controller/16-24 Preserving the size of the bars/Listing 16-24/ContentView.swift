
import SwiftUI

struct ContentView: View {
   @State private var searchURL: URL = URL(string: "http://www.formasterminds.com")!
   @State private var openSheet: Bool = false

   var body: some View {
      VStack {
         Button("Open Browser") {
            self.openSheet = true
         }
         Spacer()
      }.padding()
      .sheet(isPresented: $openSheet) {
         SafariBrowser(searchURL: self.$searchURL)
      }
   }
}
