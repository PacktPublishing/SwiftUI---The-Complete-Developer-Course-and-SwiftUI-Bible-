
import SwiftUI

struct ContentView: View {
   @State private var searchURL: URL = URL(string: "http://www.formasterminds.com")!

   var body: some View {
      VStack {
         Button("Open Web") {
            let app = UIApplication.shared
            if let scene = app.connectedScenes.first {
               scene.open(self.searchURL, options: nil, completionHandler: nil)
            }
         }
         Spacer()
      }.padding()
   }
}
