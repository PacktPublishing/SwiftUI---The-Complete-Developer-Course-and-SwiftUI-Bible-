var mynumber = 5
mynumber += 4  // 9
