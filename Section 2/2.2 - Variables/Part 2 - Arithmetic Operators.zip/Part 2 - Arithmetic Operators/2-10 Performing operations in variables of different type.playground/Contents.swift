var mynumber = 2 * 25  // 50
var anothernumber = 8 - 40 * 2  // -72
var myfraction = 5.0 / 2.0  // 2.5


var number = (8-40) * 2
var number2 = 8-40 * 2
