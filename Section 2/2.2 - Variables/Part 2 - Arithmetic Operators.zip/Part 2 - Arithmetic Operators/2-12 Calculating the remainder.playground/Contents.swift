var remainder1 = 11 % 3  // 2
var remainder2 = 20 % 8  // 4
var remainder3 = 5 % 2  // 1
