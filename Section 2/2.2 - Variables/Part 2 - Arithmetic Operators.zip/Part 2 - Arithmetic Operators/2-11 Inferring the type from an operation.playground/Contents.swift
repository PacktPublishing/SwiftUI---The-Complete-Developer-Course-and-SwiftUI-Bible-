var myfraction1 = 5.0 / 2.0  // 2.5
var myfraction2 = 5 / 2.0  // 2.5
var myfraction3: Double = 5 / 2  // 2
