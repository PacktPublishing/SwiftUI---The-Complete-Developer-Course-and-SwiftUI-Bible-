var mynumber = 5
var total = mynumber + 10  // 15
