var mynumber = 5
mynumber = mynumber + 10  // 15

mynumber = -mynumber
