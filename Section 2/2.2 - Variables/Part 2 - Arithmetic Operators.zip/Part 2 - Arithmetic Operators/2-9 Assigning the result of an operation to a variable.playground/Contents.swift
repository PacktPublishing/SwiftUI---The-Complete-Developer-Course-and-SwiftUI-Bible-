var mynumber = 5 + 10  // 15
