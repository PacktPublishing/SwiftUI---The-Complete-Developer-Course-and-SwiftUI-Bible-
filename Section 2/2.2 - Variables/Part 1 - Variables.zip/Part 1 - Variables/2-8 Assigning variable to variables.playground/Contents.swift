var mynumber = 5
var myfavorite = mynumber
