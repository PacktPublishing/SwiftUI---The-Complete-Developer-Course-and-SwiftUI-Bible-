var mynumber: Int = 5
mynumber = 87
