var mynumber: Int
