var mynumber: Int = 5
var myfavorite: Float = 14.129
