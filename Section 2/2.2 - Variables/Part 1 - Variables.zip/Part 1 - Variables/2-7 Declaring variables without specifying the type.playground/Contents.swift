var mynumber = 5
var myfavorite = 14.129
