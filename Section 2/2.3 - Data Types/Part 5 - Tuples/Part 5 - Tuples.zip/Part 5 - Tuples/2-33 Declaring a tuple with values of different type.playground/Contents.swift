var myname = ("John", "Doe", 44)
