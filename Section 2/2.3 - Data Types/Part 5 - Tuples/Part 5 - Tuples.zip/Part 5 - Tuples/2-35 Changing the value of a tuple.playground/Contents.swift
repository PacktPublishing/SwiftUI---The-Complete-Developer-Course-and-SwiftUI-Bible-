var myname = ("John", "Doe", 44)
myname.0 = "George"
var mytext = "\(myname.0) is \(myname.2) years old"
