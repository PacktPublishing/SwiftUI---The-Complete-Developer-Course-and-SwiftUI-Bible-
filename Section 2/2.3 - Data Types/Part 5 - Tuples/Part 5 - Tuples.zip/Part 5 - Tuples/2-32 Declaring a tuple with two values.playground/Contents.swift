var myname: (String, String) = ("John", "Doe")
