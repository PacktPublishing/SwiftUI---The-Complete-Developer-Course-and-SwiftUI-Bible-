var valid = true

var someBool: Bool = false
