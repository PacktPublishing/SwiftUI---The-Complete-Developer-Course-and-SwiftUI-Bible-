var mynumber: Int!
mynumber = 5
var total = mynumber * 10  // 50
