var mynumber: Int?
