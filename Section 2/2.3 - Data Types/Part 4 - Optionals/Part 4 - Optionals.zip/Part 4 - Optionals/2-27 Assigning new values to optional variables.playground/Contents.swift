var mynumber: Int?
mynumber = 5
