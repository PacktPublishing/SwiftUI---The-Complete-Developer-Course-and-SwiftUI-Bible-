var mynumber: Int?
mynumber = 5
mynumber = nil
