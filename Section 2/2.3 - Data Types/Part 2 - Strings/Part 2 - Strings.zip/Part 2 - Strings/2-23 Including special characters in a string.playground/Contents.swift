let text1 = "This is \"my\" age"  // "This is "my" age"
let text2 = #"This is "my" age"#  // "This is "my" age"
