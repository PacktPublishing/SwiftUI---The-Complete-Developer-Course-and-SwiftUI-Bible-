let age = 44
let mytext = "I am \(age) years old"  // "I am 44 years old"
