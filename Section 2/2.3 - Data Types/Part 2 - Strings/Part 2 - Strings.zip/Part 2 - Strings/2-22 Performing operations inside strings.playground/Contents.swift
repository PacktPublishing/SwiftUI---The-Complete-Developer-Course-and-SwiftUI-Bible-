let age = 44
let mytext = "I am \(age * 12) months old"  // "I am 528 months old"
