var mytext = "My name is "
mytext = mytext + "John"  // "My name is John"
