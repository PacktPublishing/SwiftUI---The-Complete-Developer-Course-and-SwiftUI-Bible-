let smileyface = "😀"
var mytext = "My name is John "
mytext += smileyface  // "My name is John 😀"
