let mytext: String = "My name is John"
