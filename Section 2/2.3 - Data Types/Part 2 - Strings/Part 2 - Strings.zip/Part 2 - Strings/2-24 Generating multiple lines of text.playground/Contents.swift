let twolines = "This is the first line\nThis is the second line"
let multiline = """
This is the first line
This is the second line
This is the third line
"""
