var myletter: Character = "A"
var myEmoji: Character = "😎"
