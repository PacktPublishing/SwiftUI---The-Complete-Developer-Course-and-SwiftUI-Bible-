var counter = 10
repeat {
   counter += 1
} while counter < 5
