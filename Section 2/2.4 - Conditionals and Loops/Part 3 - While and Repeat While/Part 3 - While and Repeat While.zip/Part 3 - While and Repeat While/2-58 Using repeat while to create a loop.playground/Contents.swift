var counter = 0
while counter < 5 {
   counter += 1
}
