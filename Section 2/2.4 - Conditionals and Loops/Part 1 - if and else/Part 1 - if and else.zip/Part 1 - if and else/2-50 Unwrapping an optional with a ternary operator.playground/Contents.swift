var age: Int? = 19
var realage = age != nil ? age! : 0  // 19
