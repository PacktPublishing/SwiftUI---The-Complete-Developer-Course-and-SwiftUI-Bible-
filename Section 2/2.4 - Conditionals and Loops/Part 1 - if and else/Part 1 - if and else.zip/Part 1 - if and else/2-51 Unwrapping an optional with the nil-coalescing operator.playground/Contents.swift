var age: Int?
var maxage = age ?? 100  // 100
