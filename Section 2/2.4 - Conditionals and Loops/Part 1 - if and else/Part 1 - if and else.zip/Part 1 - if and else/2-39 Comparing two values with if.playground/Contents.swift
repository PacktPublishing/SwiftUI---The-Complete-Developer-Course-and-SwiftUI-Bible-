var age = 19
var message = "John is old"

if age < 21 {
   message = "John is young"
}
