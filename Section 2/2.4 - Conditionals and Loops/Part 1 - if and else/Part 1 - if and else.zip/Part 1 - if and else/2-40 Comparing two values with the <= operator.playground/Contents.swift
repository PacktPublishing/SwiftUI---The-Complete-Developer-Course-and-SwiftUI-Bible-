var age = 21
var message = "John is old"
if age <= 21 {
   message = "John is young"
}
