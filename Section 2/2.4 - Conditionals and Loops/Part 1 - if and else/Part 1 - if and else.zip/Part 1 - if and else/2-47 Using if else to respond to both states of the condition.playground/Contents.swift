var mynumber = 6
if mynumber % 2 == 0 {
   mynumber = mynumber + 2  // 8
} else {
   mynumber = mynumber + 1
}
