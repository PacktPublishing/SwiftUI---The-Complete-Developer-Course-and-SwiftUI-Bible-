var underage = true
var message = "John is underage"
if !underage {
   message = "John is allowed"
}
