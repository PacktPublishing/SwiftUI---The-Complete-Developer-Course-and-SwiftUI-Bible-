var count = 0
var myoptional: Int? = 5
if let uvalue = myoptional, uvalue == 5 {
   count = count + uvalue  // 5
}
