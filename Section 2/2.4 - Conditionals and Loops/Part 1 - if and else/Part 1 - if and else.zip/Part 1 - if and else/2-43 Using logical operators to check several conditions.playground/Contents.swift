var smart = true
var age = 19
var message = "John is underage or dumb"

if (age < 21) && smart {
   message = "John is allowed"
}
