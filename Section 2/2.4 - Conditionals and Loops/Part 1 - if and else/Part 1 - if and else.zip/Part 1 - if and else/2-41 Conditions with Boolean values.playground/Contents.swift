var underage = true
var message = "John is allowed"
if underage {
   message = "John is underage"
}
