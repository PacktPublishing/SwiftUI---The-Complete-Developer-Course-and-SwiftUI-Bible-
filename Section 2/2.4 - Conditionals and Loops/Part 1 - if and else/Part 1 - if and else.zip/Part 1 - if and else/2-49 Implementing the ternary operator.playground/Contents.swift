var age = 19
var message = age < 21 ? "Underage" : "Allowed"  // "Underage"
