var age = 19
var message = ""

switch age {
   case 13:
      message = "Happy Bar Mitzvah!"
   case 16:
      message = "Sweet Sixteen!"
   case 21:
      message = "Welcome to Adulthood!"
   default:
      break
}
