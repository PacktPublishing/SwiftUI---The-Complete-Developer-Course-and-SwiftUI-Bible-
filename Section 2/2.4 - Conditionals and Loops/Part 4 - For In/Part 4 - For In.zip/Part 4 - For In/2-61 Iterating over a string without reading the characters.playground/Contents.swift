var mytext = "Hello"
var counter = 0

for _ in mytext {
   counter += 1
}
var message = "The string contains \(counter) letters"  // 5
