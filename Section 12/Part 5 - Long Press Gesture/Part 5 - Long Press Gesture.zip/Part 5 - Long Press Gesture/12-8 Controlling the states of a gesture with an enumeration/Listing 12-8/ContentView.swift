
import SwiftUI

enum PressingState {
   case active
   case inactive
    
   var isActive: Bool {
      switch self {
         case .active:
            return true
         case .inactive:
            return false
      }
   }
}
struct ContentView: View {
   @GestureState private var pressingState = PressingState.inactive
   @State private var expand: Bool = false

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
         .opacity(pressingState.isActive ? 0 : 1)
         .animation(.easeInOut(duration: 1.5))

         .gesture(LongPressGesture(minimumDuration: 1)
            .updating($pressingState) { value, state, transition in
               state = value ? .active : .inactive
            }
            .onEnded { value in
               self.expand = true
            }
         )
         .sheet(isPresented: $expand) {
            ShowImage()
         }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
