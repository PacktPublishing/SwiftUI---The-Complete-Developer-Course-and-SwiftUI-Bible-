
import SwiftUI

struct ContentView: View {
   @GestureState private var offset = CGSize.zero

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
         .offset(offset)
         .animation(.linear)

         .gesture(DragGesture(minimumDistance: 10)
            .updating($offset) { value, state, transition in
               state = value.translation
            }
         )
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
