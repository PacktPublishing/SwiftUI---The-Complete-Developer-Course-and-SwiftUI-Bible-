
import SwiftUI

struct PictureView: View {
   @EnvironmentObject var appData: AppData
    
   @State private var offset = CGSize.zero
   var picture: Picture

   var body: some View {
      Image(picture.image)
         .resizable()
         .scaledToFit()
         .offset(offset)
         .gesture(DragGesture(coordinateSpace: .global)
            .onChanged { value in
               self.appData.dropOver = self.appData.dropFrame.contains(value.location)
               self.offset = value.translation
            }
            .onEnded { value in
               if self.appData.dropOver {
                  self.appData.selected = self.picture.image
                  self.appData.remove(id: self.picture.id)
                  self.appData.dropOver = false
               } else {
                  self.offset = CGSize.zero
               }
            }
         )
   }
}
struct PictureView_Previews: PreviewProvider {
   static var previews: some View {
      PictureView(picture: Picture(image: "spot1"))
         .environmentObject(AppData())
   }
}
