
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         HStack(spacing: 10) {
            ForEach(self.appData.userData) { picture in
               PictureView(picture: picture)
            }
         }
         .frame(minWidth: 0, maxWidth: .infinity)
         .frame(height: 100)

         GeometryReader { geometry in
            VStack {
               Image(self.appData.selected ?? "nopicture")
                  .resizable()
                  .scaledToFill()
                  .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
                  .clipped()
                  .overlay(self.appData.dropOver ? Color.green.opacity(0.2) : Color.clear)
            }
            .onAppear(perform: {
               self.appData.dropFrame = geometry.frame(in: .global)
            })
         }
         .padding()
         .zIndex(-1)
      }.padding(.top)
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
