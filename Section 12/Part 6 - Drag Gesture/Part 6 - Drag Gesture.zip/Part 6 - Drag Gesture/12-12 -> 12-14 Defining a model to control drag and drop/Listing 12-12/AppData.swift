
import SwiftUI

struct Picture: Identifiable {
   var id: UUID = UUID()
   var image: String
}
class AppData: ObservableObject {
   @Published var userData: [Picture]
    
   @Published var selected: String? = nil
   @Published var dropFrame: CGRect = CGRect.zero
   @Published var dropOver: Bool = false

   init() {
      userData = [
         Picture(image: "spot1"),
         Picture(image: "spot2"),
         Picture(image: "spot3")
      ]
   }
   func remove(id: UUID) {
      if let index = userData.firstIndex(where: { $0.id == id }) {
         userData.remove(at: index)
      }
   }
}
