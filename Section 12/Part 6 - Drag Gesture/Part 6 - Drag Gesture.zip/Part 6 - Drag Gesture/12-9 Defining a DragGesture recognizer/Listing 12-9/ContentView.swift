
import SwiftUI

struct ContentView: View {
   @State private var offset = CGSize.zero

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
         .offset(offset)
         .animation(.linear)

         .gesture(DragGesture(minimumDistance: 10)
            .onChanged { value in
               self.offset = value.translation
            }
            .onEnded { value in
               self.offset = CGSize.zero
            }
         )
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
