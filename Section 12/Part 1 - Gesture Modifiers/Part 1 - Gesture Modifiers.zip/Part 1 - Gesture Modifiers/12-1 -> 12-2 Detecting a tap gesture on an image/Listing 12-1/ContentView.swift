
import SwiftUI

struct ContentView: View {
   @State private var expand: Bool = false

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
         .onTapGesture {
            self.expand = true
         }
         .sheet(isPresented: $expand) {
            ShowImage()
         }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
