
import SwiftUI

struct ContentView: View {
   @State private var selected: Bool = false

   var body: some View {
      VStack {
         HStack(alignment: .top) {
            Image("book1")
               .resizable()
               .scaledToFit()
               .frame(width: 80, height: 100)
               .border(selected ? Color.yellow : Color.clear, width: 2)

            VStack(alignment: .leading, spacing: 2) {
               Text("Steve Jobs").bold()
               Text("Walter Isaacson")
               Text("2011").font(.caption)
               Spacer()
            }.padding(.top, 5)
            Spacer()
         }.padding(5)
         .frame(maxWidth: .infinity, maxHeight: 110)
         .contentShape(Rectangle())
         .onTapGesture {
            self.selected.toggle()
         }
         Spacer()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
