
import SwiftUI

enum GesturesControl {
   case inactive
   case active
   case dragging(translation: CGSize)
    
   var isActive: Bool {
      switch self {
         case .active:
            return true
         default:
            return false
      }
   }
   var isDragging: Bool {
      switch self {
         case .dragging:
            return true
         default:
            return false
      }
   }
   var translation: CGSize {
      switch self {
         case .dragging(let translation):
            return translation
         default:
            return .zero
      }
   }
}
struct ContentView: View {
   @GestureState private var control = GesturesControl.inactive
   @State private var offset = CGSize.zero

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
            
         .overlay(control.isActive ? Color.white.opacity(0.1) : Color.clear)
         .animation(nil)
         .scaleEffect(control.isDragging ? 1.1 : 1.0)
         .shadow(color: control.isDragging ? Color.black : Color.clear, radius: 5, x: 0, y: 0)
         .animation(.easeOut(duration: 0.2))
         .offset(addToOffset(translation: control.translation))

         .gesture(LongPressGesture(minimumDuration: 1)
            .sequenced(before: DragGesture())
            .updating($control) { value, state, transaction in
               switch value {
                  case .first(true):
                     state = .active
                  case .second(true, let dragValues):
                     state = .dragging(translation: dragValues?.translation ?? CGSize.zero)
                  default:
                     state = .inactive
               }
            }
            .onEnded { value in
               if case .second(true, let dragValues?) = value {
                  self.offset = self.addToOffset(translation: dragValues.translation)
               }
            }
         )
   }
   func addToOffset(translation: CGSize) -> CGSize {
      let newOffset = CGSize(
         width: offset.width + translation.width,
         height: offset.height + translation.height
      )
      return newOffset
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
