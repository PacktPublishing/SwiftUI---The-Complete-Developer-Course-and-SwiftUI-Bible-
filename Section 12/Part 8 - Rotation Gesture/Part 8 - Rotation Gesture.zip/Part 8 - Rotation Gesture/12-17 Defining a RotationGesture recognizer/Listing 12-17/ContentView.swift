
import SwiftUI

struct ContentView: View {
   @GestureState private var rotationAngle: Angle = Angle.zero
   @State private var rotation: Angle = Angle.zero

   var body: some View {
      Image("spot1")
         .resizable()
         .scaledToFit()
         .frame(width: 160, height: 200)
         .rotationEffect(rotation + rotationAngle)

         .gesture(RotationGesture()
            .updating($rotationAngle) { value, state, transition in
               state = value
            }
            .onEnded { value in
               self.rotation = self.rotation + value
            }
         )
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
