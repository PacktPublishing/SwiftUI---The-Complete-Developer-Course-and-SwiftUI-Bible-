
import SwiftUI

struct ContentView: View {
   var body: some View {
      let device = UIDevice.current.userInterfaceIdiom

      return Group {
         if device == .phone {
            Text("iPhone")
         } else {
            Image(systemName: "keyboard")
         }
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
