
import SwiftUI

struct ContentView: View {
   var body: some View {
      VStack {
         getView()
      }
   }
   func getView() -> AnyView {
      let device = UIDevice.current.userInterfaceIdiom
      var myView: AnyView!

      if device == .phone {
         myView = AnyView(Text("iPhone"))
      } else {
         myView = AnyView(EmptyView())
      }
      return myView
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
