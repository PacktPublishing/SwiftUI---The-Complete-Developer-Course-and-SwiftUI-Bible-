
import SwiftUI

struct ContentView: View {
   var body: some View {
      Color.red
         .frame(width: 250, height: 100)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
