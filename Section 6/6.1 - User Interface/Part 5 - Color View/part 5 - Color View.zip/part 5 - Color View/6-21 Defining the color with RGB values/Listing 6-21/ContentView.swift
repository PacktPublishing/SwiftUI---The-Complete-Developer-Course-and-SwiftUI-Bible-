
import SwiftUI

struct ContentView: View {
   var body: some View {
      Color(red: 100/255, green: 228/255, blue: 255/255)
         .frame(width: 250, height: 100)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
