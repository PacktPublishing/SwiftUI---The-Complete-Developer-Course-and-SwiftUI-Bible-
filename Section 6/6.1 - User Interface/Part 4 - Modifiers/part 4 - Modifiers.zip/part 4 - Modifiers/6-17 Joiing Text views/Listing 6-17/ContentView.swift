
import SwiftUI

struct ContentView: View {
   var body: some View {
      Text("Hello ")
         .font(.largeTitle)
      + Text("World")
         .underline()
      + Text("!!!")
         .fontWeight(.heavy)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
