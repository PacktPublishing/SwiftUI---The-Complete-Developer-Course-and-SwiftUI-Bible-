
import SwiftUI

struct ContentView: View {
   var body: some View {
      Text("Hello World")
         .font(Font.system(size: 50))
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
