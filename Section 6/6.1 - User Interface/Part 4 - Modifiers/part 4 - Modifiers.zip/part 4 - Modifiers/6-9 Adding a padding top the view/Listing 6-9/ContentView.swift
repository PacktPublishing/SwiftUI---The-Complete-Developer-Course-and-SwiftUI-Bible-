
import SwiftUI

struct ContentView: View {
   var body: some View {
      Text("Hello World")
         .padding(25)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
