
import SwiftUI

struct ContentView: View {
   var number: Float = 30.87512

   var body: some View {
      Text("My Number: \(number, specifier: "%.2f")")
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
