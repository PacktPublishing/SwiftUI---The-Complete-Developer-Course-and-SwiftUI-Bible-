
import SwiftUI

struct ContentView: View {
   var number: Float = 30.87512

   var formatter: NumberFormatter {
      let format = NumberFormatter()
      format.numberStyle = .currency
      return format
   }
   var body: some View {
      Text("My Number: \(NSNumber(value: number), formatter: formatter)")
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
