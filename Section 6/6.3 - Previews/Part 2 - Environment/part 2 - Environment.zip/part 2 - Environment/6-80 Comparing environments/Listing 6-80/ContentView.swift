
import SwiftUI

struct ContentView: View {
   var body: some View {
      Text("Hello World")
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      Group {
         ContentView()
            .environment(\.sizeCategory, .small)
         ContentView()
            .environment(\.sizeCategory, .large)
         ContentView()
            .environment(\.sizeCategory, .extraExtraLarge)
      }.previewLayout(PreviewLayout.sizeThatFits)
   }
}
