
import SwiftUI

struct ContentView: View {
   @State private var textInput: String = ""

   var body: some View {
      VStack {
         TextField("Insert Caption", text: self.$textInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Spacer()
      }.padding()
      .background(Color.white
         .onTapGesture {
            self.dismissKeyboard()
         }
      )
   }
   func dismissKeyboard() {
      let windows = UIApplication.shared.windows
      let keyWindows = windows.filter({ $0.isKeyWindow })
      if !keyWindows.isEmpty {
         let window = keyWindows.first
         window?.endEditing(true)
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
