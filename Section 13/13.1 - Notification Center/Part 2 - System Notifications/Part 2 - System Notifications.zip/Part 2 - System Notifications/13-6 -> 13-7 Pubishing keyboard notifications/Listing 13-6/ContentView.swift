
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var textInput: String = ""
   @State private var offsetContainer: CGSize = CGSize.zero

   var body: some View {
      VStack {
         Image("spot1")
            .resizable()
            .scaledToFit()
         TextField("Insert Caption", text: self.$textInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .background(BackgroundView(offset: $offsetContainer))
         Spacer()
      }.padding()
      .offset(self.offsetContainer)
      .animation(.linear)
      .onReceive(self.appData.closePublisher, perform: { value in
         self.offsetContainer.height = 0
      })
   }
}
struct BackgroundView: View {
   @EnvironmentObject var appData: AppData
   @Binding var offset: CGSize

   var body: some View {
      GeometryReader { geometry in
         Color.clear
            .onReceive(self.appData.openPublisher, perform: { keyboardHeight in
               let screenWidth = UIScreen.main.bounds.width
               let screenHeight = UIScreen.main.bounds.height
               let visibleFrame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - keyboardHeight)

               let textFrame = geometry.frame(in: .global)
               if !visibleFrame.contains(textFrame) {
                  let newOffset = visibleFrame.height - geometry.size.height - 20 - textFrame.origin.y
                  self.offset.height = newOffset
               }
            })
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
