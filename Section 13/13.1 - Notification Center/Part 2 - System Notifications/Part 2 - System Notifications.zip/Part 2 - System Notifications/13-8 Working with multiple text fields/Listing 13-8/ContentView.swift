
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var offsetContainer: CGSize = CGSize.zero
   @State private var selectedField: Int? = nil

   @State private var textInput: [String] = Array.init(repeating: "", count: 10)
   let listLabels = ["Name", "Last Name", "Nickname", "Street", "Suite", "Postal Code", "City", "State", "Country", "Occupation"]

   var body: some View {
      ScrollView {
         VStack {
            Image("spot1")
               .resizable()
               .scaledToFit()
            ForEach(0..<10, id: \.self) { index in
               HStack {
                  Text("\(self.listLabels[index]):")
                  TextField("Insert \(self.listLabels[index])", text: self.$textInput[index], onEditingChanged: { value in
                     self.selectedField = value ? index : nil
                  }).textFieldStyle(RoundedBorderTextFieldStyle())
               }
               .background(BackgroundView(offset: self.$offsetContainer, selected: self.$selectedField, index: index))
            }
            Spacer()
         }.padding()
         .offset(self.offsetContainer)
      }
      .animation(.linear)
      .onReceive(self.appData.closePublisher, perform: { value in
         self.offsetContainer.height = 0
      })
   }
}
struct BackgroundView: View {
   @EnvironmentObject var appData: AppData
   @Binding var offset: CGSize
   @Binding var selected: Int?
   let index: Int

   var body: some View {
      GeometryReader { geometry in
         Color.clear
            .onReceive(self.appData.openPublisher, perform: { keyboardHeight in
               if let selIndex = self.selected, selIndex == self.index {
                  let screenWidth = UIScreen.main.bounds.width
                  let screenHeight = UIScreen.main.bounds.height
                  let visibleFrame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - keyboardHeight)

                  let textFrame = geometry.frame(in: .global)
                  if !visibleFrame.contains(textFrame) {
                     let newOffset = visibleFrame.height - geometry.size.height - 20 - textFrame.origin.y
                     self.offset.height = newOffset
                  }
               }
            })
      }
   }
}
