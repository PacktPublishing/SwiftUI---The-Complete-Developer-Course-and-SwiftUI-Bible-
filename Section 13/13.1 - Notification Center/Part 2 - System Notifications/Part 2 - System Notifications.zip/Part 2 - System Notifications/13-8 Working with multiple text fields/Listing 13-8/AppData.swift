
import SwiftUI

struct Book {
   var title: String
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []

   let openPublisher = NotificationCenter.Publisher(center: .default, name: UIWindow.keyboardWillShowNotification)
      .map({ notification -> CGFloat in
         if let info = notification.userInfo {
            let value = info[UIWindow.keyboardFrameEndUserInfoKey] as! NSValue
            let height = value.cgRectValue.height
            return height
         } else {
            return 0
         }
      })
      .receive(on: RunLoop.main)

   let closePublisher = NotificationCenter.Publisher(center: .default, name: UIWindow.keyboardDidHideNotification)
      .receive(on: RunLoop.main)
}
