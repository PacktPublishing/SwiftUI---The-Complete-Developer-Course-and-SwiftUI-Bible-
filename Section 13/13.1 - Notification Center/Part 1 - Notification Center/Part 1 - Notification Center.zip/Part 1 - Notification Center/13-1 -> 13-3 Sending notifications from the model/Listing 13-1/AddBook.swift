
import SwiftUI

struct AddBook: View {
   @EnvironmentObject var appData: AppData
   @Environment(\.presentationMode) var presentation
   @State private var titleInput: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Title")
            TextField("Insert title", text: $titleInput)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let title = self.titleInput.trimmingCharacters(in: .whitespaces)
               if !title.isEmpty {
                  self.appData.addBook(book: Book(title: title))
                  self.titleInput = ""
                  self.presentation.wrappedValue.dismiss()
               }
            }
         }
         Spacer()
      }.padding()
      .navigationBarTitle("Add Book")
   }
}

struct AddBook_Previews: PreviewProvider {
    static var previews: some View {
        AddBook()
    }
}
