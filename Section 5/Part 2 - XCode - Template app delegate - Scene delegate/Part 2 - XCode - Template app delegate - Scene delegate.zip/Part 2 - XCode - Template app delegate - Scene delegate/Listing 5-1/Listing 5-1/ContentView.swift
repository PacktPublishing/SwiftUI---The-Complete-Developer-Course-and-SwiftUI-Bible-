//
//  ContentView.swift
//  Listing 5-1
//
//  Created by John Gauchat on 2020-01-30.
//  Copyright © 2020 John Gauchat. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
