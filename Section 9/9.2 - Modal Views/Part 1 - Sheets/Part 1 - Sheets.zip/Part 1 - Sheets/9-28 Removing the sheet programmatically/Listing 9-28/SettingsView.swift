
import SwiftUI

struct SettingsView: View {
   @Environment(\.presentationMode) var presentation

   var body: some View {
      VStack {
         Button("X") {
            self.presentation.wrappedValue.dismiss()
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .trailing)
         Text("Sheet")
         Spacer()
      }.padding()
      .font(.title)
   }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
