
import SwiftUI

struct ContentView: View {
   @State private var showSheet: Bool = false

   var body: some View {
      VStack {
         Button("Open Sheet") {
            self.showSheet = true
         }.font(.title)
         Spacer()
      }.padding()
      .sheet(isPresented: $showSheet) {
         SettingsView()
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
