
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: BookViewModel? = nil

   var body: some View {
      VStack(alignment: .leading, spacing: 10) {
         Button("Open Book 1") {
            self.openSheet = self.appData.userData[0]
         }
         Button("Open Book 2") {
            self.openSheet = self.appData.userData[1]
         }
         Spacer()
      }.padding()
      .font(.title)
      .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
      .sheet(item: $openSheet) { value in
         ShowBookView(book: value)
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
