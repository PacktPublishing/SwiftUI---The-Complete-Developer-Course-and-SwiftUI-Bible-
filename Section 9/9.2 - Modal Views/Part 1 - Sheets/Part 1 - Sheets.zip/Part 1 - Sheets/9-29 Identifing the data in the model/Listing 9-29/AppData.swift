
import SwiftUI

struct Book {
   var title: String
   var author: String
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book
   var header: String {
      return book.title + " " + book.author
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel]
    
   init() {
      userData = [
         BookViewModel(book: Book(title: "Misery", author: "Stephen King")),
         BookViewModel(book: Book(title: "IT", author: "Stephen King"))
      ]
   }
}
