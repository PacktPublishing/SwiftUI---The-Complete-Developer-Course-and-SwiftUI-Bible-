
import SwiftUI

struct MoreInfoView: View {
   @Environment(\.presentationMode) var presentation

   var body: some View {
      VStack {
         Button("X") {
            self.presentation.wrappedValue.dismiss()
         }.frame(minWidth: 0, maxWidth: .infinity, alignment: .trailing)
         Text("More Information")
         Spacer()
      }.padding()
      .font(.title)
   }
}

struct MoreInfoView_Previews: PreviewProvider {
    static var previews: some View {
        MoreInfoView()
    }
}
