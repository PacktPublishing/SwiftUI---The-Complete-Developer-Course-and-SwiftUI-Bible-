
import SwiftUI

struct ContentView: View {
   var body: some View {
      VStack {
         #if targetEnvironment(macCatalyst)
            Text("Mac Application")
         #else
            Text("Mobile Application")
         #endif
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
