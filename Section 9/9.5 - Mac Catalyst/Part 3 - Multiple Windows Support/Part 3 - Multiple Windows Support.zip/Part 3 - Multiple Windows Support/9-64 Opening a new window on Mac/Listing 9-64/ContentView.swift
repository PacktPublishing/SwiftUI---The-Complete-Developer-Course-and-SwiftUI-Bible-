
import SwiftUI

struct ContentView: View {
   var body: some View {
      VStack {
         #if targetEnvironment(macCatalyst)
            Text("Mac Application")
            Button("Open New Window") {
               let app = UIApplication.shared
               app.requestSceneSessionActivation(nil, userActivity: nil, options: nil)
            }
            Spacer()
         #else
            Text("Mobile Application")
         #endif
      }.padding()
   }
}
