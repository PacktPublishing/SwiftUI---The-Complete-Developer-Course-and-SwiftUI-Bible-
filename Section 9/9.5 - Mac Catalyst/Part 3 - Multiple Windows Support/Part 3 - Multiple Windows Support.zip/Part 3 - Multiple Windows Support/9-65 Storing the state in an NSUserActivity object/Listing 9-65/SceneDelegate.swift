
import UIKit
import SwiftUI

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
   var window: UIWindow?

   func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let contentView = ContentView()
         .environmentObject(delegate.myData)

      if let windowScene = scene as? UIWindowScene {
         if let activity = connectionOptions.userActivities.first(where: { $0.activityType == "com.formasterminds.images" }) {
            if let image = activity.userInfo?["image"] as? String {
               if let index = delegate.myData.userData.firstIndex(where: { $0.picture.image == image }) {
                  delegate.myData.selectedState = index
               }
            }
         }
         let window = UIWindow(windowScene: windowScene)
         window.rootViewController = UIHostingController(rootView: contentView)
         self.window = window
         window.makeKeyAndVisible()
      }
   }
}
