
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         HStack {
            Text(appData.selectedCity ? "♥️" : "♡")
               .font(.largeTitle)
            Text("City")
            Spacer()
         }
         HStack {
            Text(appData.selectedCountry ? "♥️" : "♡")
               .font(.largeTitle)
            Text("Country")
            Spacer()
         }
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
