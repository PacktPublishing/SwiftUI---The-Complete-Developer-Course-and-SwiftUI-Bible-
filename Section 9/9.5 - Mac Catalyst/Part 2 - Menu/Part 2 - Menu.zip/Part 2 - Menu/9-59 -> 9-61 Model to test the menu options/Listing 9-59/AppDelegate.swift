
import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
   var myData: AppData!
    
   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      myData = AppData()
      return true
   }
   func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
      return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
   }
   override func buildMenu(with builder: UIMenuBuilder) {
      if builder.system == .main {
         let option1 = UICommand(title: "Select City", action: #selector(processOption1))
         let option2 = UICommand(title: "Select Country", action: #selector(processOption2))
         let mymenu = UIMenu(title: "Selection", image: nil, identifier: UIMenu.Identifier("com.formasterminds.test.selection"), children: [option1, option2])
         builder.insertSibling(mymenu, afterMenu: .format)
      } else {
         return
      }
   }
   @objc func processOption1() {
      myData.selectedCity.toggle()
   }
   @objc func processOption2() {
      myData.selectedCountry.toggle()
   }
}
