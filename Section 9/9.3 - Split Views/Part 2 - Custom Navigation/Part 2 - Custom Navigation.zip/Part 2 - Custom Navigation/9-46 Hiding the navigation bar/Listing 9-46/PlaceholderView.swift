
import SwiftUI

struct PlaceholderView: View {
   var body: some View {
      VStack {
         Text("Select a Picture")
            .font(.title)
         Spacer()
      }.padding(50)
      .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
      .background(Color(red: 0.95, green: 0.95, blue: 0.95))
   }
}

struct PlaceholderView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceholderView()
    }
}
