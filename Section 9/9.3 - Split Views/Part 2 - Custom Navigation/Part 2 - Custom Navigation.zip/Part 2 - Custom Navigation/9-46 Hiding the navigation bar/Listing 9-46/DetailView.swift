
import SwiftUI

struct DetailView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int = 0
   let device = UIDevice.current.userInterfaceIdiom

   var body: some View {
      VStack(spacing: 0) {
         BarDetailView()
         if device == .phone {
            VStack(spacing: 0) {
               DescriptionView(selected: selected)
               PictureView(selected: selected)
            }.padding(20)
         } else {
            HStack(alignment: .top) {
               iPadPictureView(selected: selected)
               iPadDescriptionView(selected: selected)
            }.padding(.top, 30)
            .padding([.leading, .trailing], 10)
         }
         Spacer()
      }
      .background(Color(red: 0.95, green: 0.95, blue: 0.95))
      .edgesIgnoringSafeArea(.all)
      .navigationBarTitle("")
      .navigationBarHidden(true)
   }
}
struct BarDetailView: View {
   let device = UIDevice.current.userInterfaceIdiom
   @Environment(\.presentationMode) var presentation
   @State private var openAlert: Bool = false

   var body: some View {
      HStack {
         if device == .phone {
            Button(action: {
               self.presentation.wrappedValue.dismiss()
            }, label: {
               Image(systemName: "arrow.left.circle")
                  .font(Font.system(size: 30))
                  .foregroundColor(.black)
            }).padding(.trailing, 8)
         }
         Text("Picture")
            .font(.title)
         Spacer()
         Button(action: {
            self.openAlert = true
         }, label: {
            Image(systemName: "trash.circle")
               .font(Font.system(size: 30))
               .foregroundColor(.black)
         }).padding(.trailing, 8)
         NavigationLink(destination: AddPictureView(), label: {
            Image(systemName: "plus.circle")
               .font(Font.system(size: 30))
               .foregroundColor(.black)
         })
      }.padding()
      .padding(.top, 35)
      .frame(height: 95)
      .frame(minWidth: 0, maxWidth: .infinity)
      .background(Color(red: 250/255, green: 255/255, blue: 178/255))
      .alert(isPresented: $openAlert, content: {
         Alert(title: Text("Delete Picture"), message: Text("Are you sure?"), primaryButton: .cancel(), secondaryButton: .destructive(Text("Delete")))
      })
   }
}
struct DescriptionView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      HStack {
         Text("Rating: ")
            .font(.subheadline)
         Slider(value: $appData.userData[selected].picture.rating, in: 0...5, step: 1.0)
            .frame(width: 150)
         Text("\(appData.userData[selected].rating)")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.orange)
         Spacer()
      }.padding(.bottom, 15)
   }
}
struct PictureView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      Image(appData.userData[selected].picture.image)
         .resizable()
         .aspectRatio(contentMode: .fill)
         .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
         .clipped()
   }
}
struct iPadDescriptionView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      VStack(alignment: .leading, spacing: 10) {
         HStack {
            Text("Name: ")
            Text(appData.userData[selected].picture.image)
               .bold()
         }.font(.title)
         HStack {
            Text("Number: ")
            Text(String(selected))
               .bold()
         }.font(.title)
         HStack {
            Text("Rating: ")
            Slider(value: $appData.userData[selected].picture.rating, in: 0...5, step: 1.0)
               .frame(width: 150)
            Text("\(appData.userData[selected].rating)")
               .font(.title)
               .fontWeight(.bold)
               .foregroundColor(Color.orange)
         }.font(.title)
      }.frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
   }
}
struct iPadPictureView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      Image(appData.userData[selected].picture.image)
         .resizable()
         .scaledToFit()
         .cornerRadius(20)
         .frame(width: 300, height: 300)
         .clipped()
   }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
