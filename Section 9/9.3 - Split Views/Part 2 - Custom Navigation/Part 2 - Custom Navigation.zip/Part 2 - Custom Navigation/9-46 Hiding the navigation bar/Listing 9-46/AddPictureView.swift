//
//  AddPictureView.swift
//  Listing 9-46
//
//  Created by John Gauchat on 2020-01-31.
//  Copyright © 2020 John Gauchat. All rights reserved.
//

import SwiftUI

struct AddPictureView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct AddPictureView_Previews: PreviewProvider {
    static var previews: some View {
        AddPictureView()
    }
}
