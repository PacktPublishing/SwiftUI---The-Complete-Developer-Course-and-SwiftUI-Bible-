
import SwiftUI

struct DetailView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int = 0
   let device = UIDevice.current.userInterfaceIdiom

   var body: some View {
      VStack(spacing: 0) {
         if device == .phone {
            VStack(spacing: 0) {
               DescriptionView(selected: selected)
               PictureView(selected: selected)
            }.padding(20)
         } else {
            HStack(alignment: .top) {
               iPadPictureView(selected: selected)
               iPadDescriptionView(selected: selected)
            }.padding(.top, 30)
            .padding([.leading, .trailing], 10)
         }
         Spacer()
      }
      .background(Color(red: 0.95, green: 0.95, blue: 0.95))
      .navigationBarTitle("Picture", displayMode: .inline)
   }
}
struct DescriptionView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      HStack {
         Text("Rating: ")
            .font(.subheadline)
         Slider(value: $appData.userData[selected].picture.rating, in: 0...5, step: 1.0)
            .frame(width: 150)
         Text("\(appData.userData[selected].rating)")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.orange)
         Spacer()
      }.padding(.bottom, 15)
   }
}
struct PictureView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      Image(appData.userData[selected].picture.image)
         .resizable()
         .aspectRatio(contentMode: .fill)
         .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
         .clipped()
   }
}
struct iPadDescriptionView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      VStack(alignment: .leading, spacing: 10) {
         HStack {
            Text("Name: ")
            Text(appData.userData[selected].picture.image)
               .bold()
         }.font(.title)
         HStack {
            Text("Number: ")
            Text(String(selected))
               .bold()
         }.font(.title)
         HStack {
            Text("Rating: ")
            Slider(value: $appData.userData[selected].picture.rating, in: 0...5, step: 1.0)
               .frame(width: 150)
            Text("\(appData.userData[selected].rating)")
               .font(.title)
               .fontWeight(.bold)
               .foregroundColor(Color.orange)
         }.font(.title)
      }.frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
   }
}
struct iPadPictureView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      Image(appData.userData[selected].picture.image)
         .resizable()
         .scaledToFit()
         .cornerRadius(20)
         .frame(width: 300, height: 300)
         .clipped()
   }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
