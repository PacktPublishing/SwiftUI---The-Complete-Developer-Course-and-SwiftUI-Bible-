
import SwiftUI

struct MenuView: View {
   @State private var selectedLink: Int? = nil

   var body: some View {
      VStack(alignment: .leading, spacing: 15) {
         NavigationLink("🖼 Picture 1", destination: DetailView(selected: 1), tag: 1, selection: $selectedLink)
         NavigationLink("🖼 Picture 2", destination: DetailView(selected: 2), tag: 2, selection: $selectedLink)
         NavigationLink("🖼 Picture 3", destination: DetailView(selected: 3), tag: 3, selection: $selectedLink)
         Spacer()
      }.font(.title)
      .padding()
      .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
      .navigationBarTitle("Menu")
   }
}

struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}
