
import SwiftUI

struct ContentView: View {
   var body: some View {
      GeometryReader { geometry in
         Image("spot1")
            .resizable()
            .scaledToFit()
            .frame(width: geometry.size.width / 2, height: geometry.size.height / 4)
            .background(Color.gray)
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
