
import SwiftUI

struct ContentView: View {
   var body: some View {
      GeometryReader { geometry in
         VStack {
            Image("spot1")
               .resizable()
               .scaledToFit()
               .frame(width: geometry.size.width / 2, height: geometry.size.height / 2)
            Text("Global: \(geometry.frame(in: .global).origin.x, specifier: "%.f") / \(geometry.frame(in: .global).origin.y, specifier: "%.f")")
            Text("Local: \(geometry.frame(in: .local).origin.x, specifier: "%.f") / \(geometry.frame(in: .local).origin.y, specifier: "%.f")")
         }
      }.frame(height: 200)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
