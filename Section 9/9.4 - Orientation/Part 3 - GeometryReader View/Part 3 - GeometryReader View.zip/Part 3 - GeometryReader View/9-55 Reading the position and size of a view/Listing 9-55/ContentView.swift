
import SwiftUI

struct ContentView: View {
   @State private var size: CGSize = CGSize.zero

   var body: some View {
      VStack {
         Image("spot1")
            .resizable()
            .scaledToFit()
            .background(
               GeometryReader { geometry in
                  Color.clear
                     .onAppear(perform: {
                        self.size = geometry.size
                     })
               })
         Text("\(size.width, specifier: "%.2f") x \(size.height, specifier: "%.2f")")
      }.padding([.leading, .trailing], 100)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
