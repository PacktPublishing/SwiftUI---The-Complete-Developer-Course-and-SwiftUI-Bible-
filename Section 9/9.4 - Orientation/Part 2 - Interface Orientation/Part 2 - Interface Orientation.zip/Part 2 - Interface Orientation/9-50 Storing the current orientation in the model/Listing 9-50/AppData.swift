
import SwiftUI

class AppData: ObservableObject {
   @Published var isPortrait: Bool = true
}
