
import SwiftUI

struct BoxPreference: PreferenceKey {
   typealias Value = CGSize
   static var defaultValue: CGSize = CGSize.zero

   static func reduce(value: inout CGSize, nextValue: () -> CGSize) {
      value = nextValue()
   }
}
struct ContentView: View {
   @State private var setColor: Bool = false

   var body: some View {
      VStack {
         GeometryReader { geometry in
            Image("spot1")
               .resizable()
               .scaledToFit()
               .frame(width: geometry.size.width, height: geometry.size.height / 2)
               .preference(key: BoxPreference.self, value: geometry.size)
         }
      }.frame(height: 200)
      .background(setColor ? Color.yellow : Color.clear)
      .onPreferenceChange(BoxPreference.self, perform: { value in
         self.setColor = value.width > 500
      })
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
