
import SwiftUI

struct ContentView: View {
   var body: some View {
      NavigationView {
         VStack {
            Text("Hello World")
            Spacer()
         }.padding()
         .navigationBarTitle("Home Screen")
      }.statusBar(hidden: true)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
