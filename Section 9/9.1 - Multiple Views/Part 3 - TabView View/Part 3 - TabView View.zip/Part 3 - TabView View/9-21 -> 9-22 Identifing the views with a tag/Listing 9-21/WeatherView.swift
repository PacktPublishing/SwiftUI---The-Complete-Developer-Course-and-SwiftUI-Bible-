
import SwiftUI

struct WeatherView: View {
   var body: some View {
      Text("Weather")
         .font(.largeTitle)
   }
}

struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        WeatherView()
    }
}
