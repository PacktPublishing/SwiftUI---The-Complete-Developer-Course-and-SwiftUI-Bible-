
import SwiftUI

struct SettingsView: View {
   @Binding var selected: Int

   var body: some View {
      VStack(spacing: 15) {
         Text("Settings")
            .font(.largeTitle)
         Button("Open Weather") {
            self.selected = 0
         }
      }
   }
}
struct SettingsView_Previews: PreviewProvider {
   static var previews: some View {
      SettingsView(selected: .constant(0))
   }
}
