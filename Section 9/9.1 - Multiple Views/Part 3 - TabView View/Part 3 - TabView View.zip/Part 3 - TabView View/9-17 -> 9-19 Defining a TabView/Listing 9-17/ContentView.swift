
import SwiftUI

struct ContentView: View {
   var body: some View {
      TabView {
         WeatherView()
            .tabItem({
               Image(systemName: "sun.max")
               Text("Weather")
            })
         SettingsView()
            .tabItem({
               Image(systemName: "gear")
               Text("Settings")
            })
      }.edgesIgnoringSafeArea(.top)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
