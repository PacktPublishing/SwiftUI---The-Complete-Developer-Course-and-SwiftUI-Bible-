
import SwiftUI

struct ContentView: View {
   var body: some View {
      TabView {
         WeatherView()
            .tabItem({
               Image(systemName: "sun.max")
               Text("Weather")
            }).font(.body)
         SettingsView()
            .tabItem({
               Image(systemName: "gear")
               Text("Settings")
            }).font(.body)
      }.font(.title)
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
