
import SwiftUI

struct SecondView: View {
   var body: some View {
      VStack(spacing: 5) {
         Text("This is the content of the")
         Text("second screen")
         Spacer()
      }.padding()
      .navigationBarTitle("Second Screen")
   }
}
struct SecondView_Previews: PreviewProvider {
   static var previews: some View {
      NavigationView {
         SecondView()
      }
   }
}
