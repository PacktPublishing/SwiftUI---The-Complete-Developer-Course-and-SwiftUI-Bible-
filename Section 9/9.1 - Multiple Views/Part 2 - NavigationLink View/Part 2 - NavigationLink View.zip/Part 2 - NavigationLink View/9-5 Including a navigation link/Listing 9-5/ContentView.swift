
import SwiftUI

struct ContentView: View {
   var body: some View {
      NavigationView {
         VStack(spacing: 15) {
            Text("Hello World")
            NavigationLink("Show Second Screen", destination: SecondView())
            Spacer()
         }.padding()
         .navigationBarTitle("Home Screen")
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
