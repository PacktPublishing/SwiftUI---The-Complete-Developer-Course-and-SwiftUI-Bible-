
import SwiftUI

struct SecondView: View {
    @Environment(\.presentationMode) var presentation

   var body: some View {
      VStack(spacing: 5) {
         Text("This is the content of the")
         Text("second screen")
         Spacer()
      }.padding()
      .navigationBarTitle("Second Screen")
      .navigationBarBackButtonHidden(true)
      .navigationBarItems(leading: Button("Go Back") {
         self.presentation.wrappedValue.dismiss()
      })
   }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView()
    }
}
