
import SwiftUI

struct DetailView: View {
   @EnvironmentObject var appData: AppData
   var selected: Int

   var body: some View {
      VStack {
         HStack {
            Text("Rating: ")
               .font(.subheadline)
            Slider(value: $appData.userData[selected].picture.rating, in: 0...5, step: 1.0)
               .frame(width: 150)
            Text("\(appData.userData[selected].rating)")
               .font(.title)
               .fontWeight(.bold)
               .foregroundColor(Color.orange)
            Spacer()
         }
         Image(appData.userData[selected].picture.image)
            .resizable()
            .aspectRatio(contentMode: .fill)
            .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
            .clipped()
      }.padding(15)
      .background(Color(red: 0.95, green: 0.95, blue: 0.95))
      .navigationBarTitle("Picture", displayMode: .inline)
   }
}
struct DetailView_Previews: PreviewProvider {
   static var previews: some View {
      NavigationView {
         DetailView(selected: 0).environmentObject(AppData())
      }
   }
}
