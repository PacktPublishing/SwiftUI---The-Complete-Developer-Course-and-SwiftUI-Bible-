
import SwiftUI

struct ThirdView: View {
   var body: some View {
      VStack(spacing: 5) {
         Text("This is the content of the")
         Text("third screen")
         Spacer()
      }.padding()
      .navigationBarTitle("Third Screen")
   }
}
struct ThirdView_Previews: PreviewProvider {
   static var previews: some View {
      NavigationView {
         ThirdView()
      }
   }
}
