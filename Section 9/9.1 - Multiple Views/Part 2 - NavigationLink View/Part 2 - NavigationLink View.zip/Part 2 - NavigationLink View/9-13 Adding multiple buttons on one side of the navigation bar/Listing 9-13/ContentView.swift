
import SwiftUI

struct ContentView: View {
   @State private var activeLink: Bool = false

   var body: some View {
      NavigationView {
         VStack(spacing: 15) {
            Text("Hello World")
            Button("Show Second Screen") {
               self.activeLink = true
            }
            NavigationLink(destination: SecondView(active: $activeLink), isActive: $activeLink, label: {
               EmptyView()
            })
            Spacer()
         }.padding()
         .navigationBarTitle("Home Screen")
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
