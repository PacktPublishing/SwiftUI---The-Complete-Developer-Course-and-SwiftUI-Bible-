
import SwiftUI

struct SecondView: View {
   @Binding var active: Bool

   var body: some View {
      VStack(spacing: 5) {
         Text("This is the content of the")
         Text("second screen")
         Spacer()
      }.padding()
      .navigationBarTitle("Second Screen")
      .navigationBarBackButtonHidden(true)
      .navigationBarItems(leading: Button("Go Back") {
         self.active = false
      }, trailing: NavigationLink(destination: ThirdView(), label: {
         Image(systemName: "plus.circle")
      }))
   }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView(active: .constant(false))
    }
}
