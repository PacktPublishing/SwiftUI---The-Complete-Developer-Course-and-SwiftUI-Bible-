
import SwiftUI

struct InsertInfoView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool

   @State private var inputName: String = ""
   @State private var inputAddress: String = ""
   @State private var inputCity: String = ""

   var body: some View {
      VStack(spacing: 10) {
         TextField("Insert Name", text: $inputName)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert Address", text: $inputAddress)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert City", text: $inputCity)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         HStack {
            Spacer()
            Button("Save") {
               self.appData.userInfo = PersonalInfo(name: self.inputName, address: self.inputAddress, city: self.inputCity)
               self.appData.saveFile()
               self.openSheet = false
            }
         }
         Spacer()
      }.padding()
      .onAppear(perform: {
         self.inputName = self.appData.userInfo.name
         self.inputAddress = self.appData.userInfo.address
         self.inputCity = self.appData.userInfo.city
      })
   }
}
struct InsertInfoView_Previews: PreviewProvider {
   static var previews: some View {
      InsertInfoView(openSheet: .constant(false))
         .environmentObject(AppData())
   }
}
