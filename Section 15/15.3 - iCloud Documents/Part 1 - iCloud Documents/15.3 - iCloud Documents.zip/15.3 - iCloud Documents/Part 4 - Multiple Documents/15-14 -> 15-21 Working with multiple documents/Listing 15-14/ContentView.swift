
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         List {
            ForEach(appData.listOfFiles) { file in
               NavigationLink(destination: ShowFileView(info: file)) {
                  Text(file.name)
               }
            }.onDelete(perform: { indexes in
               self.appData.removeFiles(indexes: indexes)
            })
         }
         .navigationBarTitle("List of Files")
         .navigationBarItems(trailing: Button("Create File") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            CreateFileView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
