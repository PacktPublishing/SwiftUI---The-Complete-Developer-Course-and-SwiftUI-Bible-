
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack {
         HStack {
            Stepper("", value: $appData.control)
               .labelsHidden()
            Text("\(appData.control, specifier: "%.f")")
               .font(.title)
            Spacer()
         }
         Spacer()
      }.padding()
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
