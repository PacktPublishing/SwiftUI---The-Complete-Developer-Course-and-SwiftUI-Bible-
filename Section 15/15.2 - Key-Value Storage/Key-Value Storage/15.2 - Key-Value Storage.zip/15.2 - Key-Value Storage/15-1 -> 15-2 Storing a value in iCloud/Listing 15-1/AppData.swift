
import SwiftUI
import Combine

class AppData: ObservableObject {
   @Published var control: Double = 0 {
      didSet {
         let kvStorage = NSUbiquitousKeyValueStore()
         kvStorage.set(control, forKey: "control")
         kvStorage.synchronize()
      }
   }
   init() {
      self.readControl()
        
      let publisher = NotificationCenter.Publisher(center: .default, name: NSUbiquitousKeyValueStore.didChangeExternallyNotification)
         .receive(on: RunLoop.main)
      let subscriber = Subscribers.Sink<Notification, Never>(receiveCompletion: {_ in }, receiveValue: {_ in
         self.readControl()
      })
      publisher.subscribe(subscriber)
   }
   func readControl() {
      let kvStorage = NSUbiquitousKeyValueStore()
      let sharedControl = kvStorage.double(forKey: "control")
      control = sharedControl
   }
}
