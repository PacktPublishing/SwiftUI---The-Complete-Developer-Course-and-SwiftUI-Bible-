
import SwiftUI
import CloudKit

struct InsertCityView: View {
   @EnvironmentObject var appData: AppData
   @Binding var openSheet: Bool
   @State private var inputName: String = ""
   let country: CKRecord.ID

   var body: some View {
      VStack {
         HStack {
            Text("City:")
            TextField("Insert City", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let text = self.inputName.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  self.appData.insertCity(name: text, country: self.country)
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}
struct InsertCityView_Previews: PreviewProvider {
   static var previews: some View {
      InsertCityView(openSheet: .constant(false), country: CKRecord.ID(recordName: "Test"))
         .environmentObject(AppData())
   }
}
