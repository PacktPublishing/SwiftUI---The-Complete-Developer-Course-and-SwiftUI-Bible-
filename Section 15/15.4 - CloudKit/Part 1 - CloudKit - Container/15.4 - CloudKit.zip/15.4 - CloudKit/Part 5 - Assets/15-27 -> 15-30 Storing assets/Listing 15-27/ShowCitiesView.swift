
import SwiftUI
import CloudKit

struct ShowCitiesView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false
   let selectedCountry: CountryViewModel

   var body: some View {
      VStack {
         List {
            ForEach(appData.listCities) { city in
               NavigationLink(destination: ShowPictureView(selectedCity: city)) {
                  Text(city.cityName)
               }
            }
         }
      }
      .navigationBarTitle(self.selectedCountry.countryName)
      .navigationBarItems(trailing: Button("Add City") {
         self.openSheet = true
      })
      .sheet(isPresented: $openSheet) {
         InsertCityView(openSheet: self.$openSheet, country: self.selectedCountry.id)
            .environmentObject(self.appData)
      }
      .onAppear(perform: {
         self.appData.readCities(country: self.selectedCountry.id)
      })
   }
}
struct ShowCitiesView_Previews: PreviewProvider {
   static var previews: some View {
      ShowCitiesView(selectedCountry: CountryViewModel(id: CKRecord.ID(recordName: "Test"), country: Country(name: "Test", record: CKRecord(recordType: "Cities", recordID: CKRecord.ID(recordName: "Test")))))
         .environmentObject(AppData())
   }
}
