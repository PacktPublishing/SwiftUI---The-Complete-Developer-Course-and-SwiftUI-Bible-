
import SwiftUI
import CloudKit

struct ShowPictureView: View {
   @EnvironmentObject var appData: AppData
   let selectedCity: CityViewModel

   var body: some View {
      Image(uiImage: self.selectedCity.cityPicture)
         .resizable()
         .scaledToFit()
         .navigationBarTitle(selectedCity.cityName)
   }
}
struct ShowPictureView_Previews: PreviewProvider {
   static var previews: some View {
      ShowPictureView(selectedCity: CityViewModel(id: CKRecord.ID(recordName: "Test"), city: City(name: "Test", record: CKRecord(recordType: "Cities", recordID: CKRecord.ID(recordName: "Test")))))
   }
}
