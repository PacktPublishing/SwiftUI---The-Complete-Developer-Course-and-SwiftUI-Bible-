
import SwiftUI

struct ContentView: View {
   @EnvironmentObject var appData: AppData
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         List {
            ForEach(appData.listCountries) { country in
               NavigationLink(destination: ShowCitiesView(selectedCountry: country)) {
                  Text(country.countryName)
               }
            }
         }
         .navigationBarTitle("Countries")
         .navigationBarItems(trailing: Button("Add Country") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            InsertCountryView(openSheet: self.$openSheet)
               .environmentObject(self.appData)
         }
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
