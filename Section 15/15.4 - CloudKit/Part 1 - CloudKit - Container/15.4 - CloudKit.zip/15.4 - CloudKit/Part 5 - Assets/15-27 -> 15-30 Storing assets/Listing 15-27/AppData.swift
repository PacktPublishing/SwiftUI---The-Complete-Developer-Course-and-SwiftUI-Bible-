
import SwiftUI
import CloudKit

struct Country {
   let name: String?
   let record: CKRecord
}
struct City {
   let name: String?
   let record: CKRecord
}
struct CountryViewModel: Identifiable {
   let id: CKRecord.ID
   let country: Country
    
   var countryName: String {
      return country.name ?? "Undefined"
   }
}
struct CityViewModel: Identifiable {
   let id: CKRecord.ID
   let city: City

   var cityName: String {
      return city.name ?? "Undefined"
   }
   var cityPicture: UIImage {
      if let asset = city.record["picture"] as? CKAsset, let fileURL = asset.fileURL {
         if let picture = UIImage(contentsOfFile: fileURL.path) {
            return picture
         }
      }
      return UIImage(named: "nopicture")!
   }
}
class AppData: ObservableObject {
   @Published var listCountries: [CountryViewModel] = []
   @Published var listCities: [CityViewModel] = []
   var database: CKDatabase!

   init() {
      let container = CKContainer.default()
      database = container.privateCloudDatabase
        
      self.readCountries()
   }
   func insertCountry(name: String) {
      let id = CKRecord.ID(recordName: "idcountry-\(UUID())")
      let record = CKRecord(recordType: "Countries", recordID: id)
      record.setObject(name as NSString, forKey: "name")

      database.save(record, completionHandler: { (recordSaved, error) in
         if error == nil {
            let main = OperationQueue.main
            main.addOperation {
               let newCountry = Country(name: record["name"], record: record)
               let newItem = CountryViewModel(id: record.recordID, country: newCountry)
               self.listCountries.append(newItem)
               self.listCountries.sort(by: { $0.countryName < $1.countryName })
            }
         } else {
            print("Error: record not saved \(error!)")
         }
      })
   }
   func insertCity(name: String, country: CKRecord.ID) {
      let id = CKRecord.ID(recordName: "idcity-\(UUID())")
      let record = CKRecord(recordType: "Cities", recordID: id)
      record.setObject(name as NSString, forKey: "name")
      let reference = CKRecord.Reference(recordID: country, action: .deleteSelf)
      record.setObject(reference, forKey: "country")
   
      let bundle = Bundle.main
      if let fileURL = bundle.url(forResource: "Toronto", withExtension: "jpg") {
         let asset = CKAsset(fileURL: fileURL)
         record.setObject(asset, forKey: "picture")
      }
      database.save(record, completionHandler: { (recordSaved, error) in
         if error == nil {
            let main = OperationQueue.main
            main.addOperation {
               let newCity = City(name: record["name"], record: record)
               let newItem = CityViewModel(id: record.recordID, city: newCity)
               self.listCities.append(newItem)
               self.listCities.sort(by: { $0.cityName < $1.cityName })
            }
         } else {
            print("Error: record not saved \(error!)")
         }
      })
   }
   func readCountries() {
      let predicate = NSPredicate(format: "TRUEPREDICATE")
      let query = CKQuery(recordType: "Countries", predicate: predicate)
      database.perform(query, inZoneWith: nil, completionHandler: { (records, error) in
         if let list = records, error == nil {
            let main = OperationQueue.main
            main.addOperation {
               self.listCountries = []
               for record in list {
                  let newCountry = Country(name: record["name"], record: record)
                  let newItem = CountryViewModel(id: record.recordID, country: newCountry)
                  self.listCountries.append(newItem)
               }
               self.listCountries.sort(by: { $0.countryName < $1.countryName })
            }
         } else {
            print("Error: records not found \(error!)")
         }
      })
   }
   func readCities(country: CKRecord.ID) {
      let predicate = NSPredicate(format: "country = %@", country)
      let query = CKQuery(recordType: "Cities", predicate: predicate)
      database.perform(query, inZoneWith: nil, completionHandler: { (records, error) in
         if let list = records, error == nil {
            let main = OperationQueue.main
            main.addOperation {
               self.listCities = []
               for record in list {
                  let newCity = City(name: record["name"], record: record)
                  let newItem = CityViewModel(id: record.recordID, city: newCity)
                  self.listCities.append(newItem)
               }
               self.listCities.sort(by: { $0.cityName < $1.cityName })
            }
         } else {
            print("Error: records not found \(error!)")
         }
      })
   }
}
