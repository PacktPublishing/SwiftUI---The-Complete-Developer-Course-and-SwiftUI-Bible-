
import SwiftUI
import CoreData

struct InsertCityView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Binding var openSheet: Bool
   @State private var inputName: String = ""
   let country: Countries

   var body: some View {
      VStack {
         HStack {
            Text("City:")
            TextField("Insert City", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let text = self.inputName.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  let newCity = Cities(context: self.dbContext)
                  newCity.name = text
                  newCity.country = self.country
                  do {
                     try self.dbContext.save()
                  } catch {
                     print("Error saving city")
                  }
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}
struct InsertCityView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext

      let country = Countries(context: dbContext)
      country.name = "Test"
      return InsertCityView(openSheet: .constant(false), country: country).environment(\.managedObjectContext, dbContext)
   }
}
