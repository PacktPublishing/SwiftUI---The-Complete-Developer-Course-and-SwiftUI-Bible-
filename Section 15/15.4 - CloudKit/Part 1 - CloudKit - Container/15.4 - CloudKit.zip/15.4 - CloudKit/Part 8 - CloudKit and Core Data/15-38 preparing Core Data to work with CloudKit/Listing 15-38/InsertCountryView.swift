
import SwiftUI
import CoreData

struct InsertCountryView: View {
   @Environment(\.managedObjectContext) var dbContext
   @Binding var openSheet: Bool
   @State private var inputName: String = ""

   var body: some View {
      VStack {
         HStack {
            Text("Country:")
            TextField("Insert Country", text: $inputName)
               .textFieldStyle(RoundedBorderTextFieldStyle())
         }
         HStack {
            Spacer()
            Button("Save") {
               let text = self.inputName.trimmingCharacters(in: .whitespaces)
               if !text.isEmpty {
                  let newCountry = Countries(context: self.dbContext)
                  newCountry.name = text
                  do {
                     try self.dbContext.save()
                  } catch {
                     print("Error saving country")
                  }
                  self.openSheet = false
               }
            }
         }
         Spacer()
      }.padding()
   }
}
struct InsertCountryView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return InsertCountryView(openSheet: .constant(false))
         .environment(\.managedObjectContext, dbContext)
   }
}
