
import SwiftUI
import CoreData

struct ContentView: View {
   @Environment(\.managedObjectContext) var dbContext
   @FetchRequest(entity: Countries.entity(), sortDescriptors: [NSSortDescriptor(key: "name", ascending: true)]) var listCountries: FetchedResults<Countries>
   @State private var openSheet: Bool = false

   var body: some View {
      NavigationView {
         List {
            ForEach(listCountries, id: \.self) { country in
               NavigationLink(destination: ShowCitiesView(selectedCountry: country)) {
                  Text(country.name ?? "Undefined")
               }
            }
         }
         .navigationBarTitle("Countries")
         .navigationBarItems(trailing: Button("Add Country") {
            self.openSheet = true
         })
         .sheet(isPresented: $openSheet) {
            InsertCountryView(openSheet: self.$openSheet)
               .environment(\.managedObjectContext, self.dbContext)
         }
      }
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      let app = UIApplication.shared
      let delegate = app.delegate as! AppDelegate
      let dbContext = delegate.persistentContainer.viewContext
      return ContentView().environment(\.managedObjectContext, dbContext)
   }
}
