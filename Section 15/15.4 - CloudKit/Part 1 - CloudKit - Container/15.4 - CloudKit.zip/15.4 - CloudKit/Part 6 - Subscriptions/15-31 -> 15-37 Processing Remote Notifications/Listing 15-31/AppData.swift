
import SwiftUI
import CloudKit

struct Country {
   let name: String?
   let record: CKRecord
}
struct City {
   let name: String?
   let record: CKRecord
}
struct CountryViewModel: Identifiable {
   let id: CKRecord.ID
   let country: Country
    
   var countryName: String {
      return country.name ?? "Undefined"
   }
}
struct CityViewModel: Identifiable {
   let id: CKRecord.ID
   let city: City

   var cityName: String {
      return city.name ?? "Undefined"
   }
   var cityPicture: UIImage {
      if let asset = city.record["picture"] as? CKAsset, let fileURL = asset.fileURL {
         if let picture = UIImage(contentsOfFile: fileURL.path) {
            return picture
         }
      }
      return UIImage(named: "nopicture")!
   }
}
class AppData: ObservableObject {
   @Published var listCountries: [CountryViewModel] = []
   @Published var listCities: [CityViewModel] = []
   var database: CKDatabase!

   init() {
      let container = CKContainer.default()
      database = container.privateCloudDatabase
        
      self.readCountries()
      self.checkZones()
   }
    
    var listChanges: Set<String> = []
    
  func insertCountry(name: String) {
    self.listChanges.insert(name)
    configureDatabase(executeClosure: {
        let container = CKContainer.default()
        container.accountStatus(completionHandler: { (status, error) in
            if status == CKAccountStatus.available && !self.listChanges.isEmpty {
                for itemName in self.listChanges {
                    let zone = CKRecordZone(zoneName: "listPlaces")
                    let id = CKRecord.ID(recordName: "idcountry-\(UUID())", zoneID: zone.zoneID)
                    let record = CKRecord(recordType: "Countries", recordID: id)
                    record.setObject(itemName as NSString, forKey: "name")
                    
                    self.database.save(record, completionHandler: { (recordSaved, error) in
                        if error == nil {
                            let main = OperationQueue.main
                            main.addOperation {
                                let newCountry = Country(name: record["name"], record: record)
                                let newItem = CountryViewModel(id: record.recordID, country: newCountry); self.listCountries.append(newItem)
                                self.listCountries.sort(by: { $0.countryName < $1.countryName }); self.listChanges.remove(itemName)
                                }
                        } else {
                            print("Error: record not saved \(error!)")
                        }
                    })
                }
            }
        })
     })
    
    }

 
                                
   func insertCity(name: String, country: CKRecord.ID) {
      configureDatabase(executeClosure: {
         let zone = CKRecordZone(zoneName: "listPlaces")
         let id = CKRecord.ID(recordName: "idcity-\(UUID())", zoneID: zone.zoneID)
         let record = CKRecord(recordType: "Cities", recordID: id)
         record.setObject(name as NSString, forKey: "name")
               
         let reference = CKRecord.Reference(recordID: country, action: .deleteSelf)
         record.setObject(reference, forKey: "country")
   
         let bundle = Bundle.main
         if let fileURL = bundle.url(forResource: "Toronto", withExtension: "jpg") {
            let asset = CKAsset(fileURL: fileURL)
            record.setObject(asset, forKey: "picture")
         }
         self.database.save(record, completionHandler: { (recordSaved, error) in
            if error == nil {
               let main = OperationQueue.main
               main.addOperation {
                  let newCity = City(name: record["name"], record: record)
                  let newItem = CityViewModel(id: record.recordID, city: newCity)
                  self.listCities.append(newItem)
                  self.listCities.sort(by: { $0.cityName < $1.cityName })
               }
            } else {
               print("Error: record not saved \(error!)")
            }
         })
      })
   }
   func readCountries() {
      let predicate = NSPredicate(format: "TRUEPREDICATE")
      let query = CKQuery(recordType: "Countries", predicate: predicate)
      database.perform(query, inZoneWith: nil, completionHandler: { (records, error) in
         if let list = records, error == nil {
            let main = OperationQueue.main
            main.addOperation {
               self.listCountries = []
               for record in list {
                  let newCountry = Country(name: record["name"], record: record)
                  let newItem = CountryViewModel(id: record.recordID, country: newCountry)
                  self.listCountries.append(newItem)
               }
               self.listCountries.sort(by: { $0.countryName < $1.countryName })
            }
         } else {
            print("Error: records not found \(error!)")
         }
      })
   }
   func readCities(country: CKRecord.ID) {
      let predicate = NSPredicate(format: "country = %@", country)
      let query = CKQuery(recordType: "Cities", predicate: predicate)
      database.perform(query, inZoneWith: nil, completionHandler: { (records, error) in
         if let list = records, error == nil {
            let main = OperationQueue.main
            main.addOperation {
               self.listCities = []
               for record in list {
                  let newCity = City(name: record["name"], record: record)
                  let newItem = CityViewModel(id: record.recordID, city: newCity)
                  self.listCities.append(newItem)
               }
               self.listCities.sort(by: { $0.cityName < $1.cityName })
            }
         } else {
            print("Error: records not found \(error!)")
         }
      })
   }
   func configureDatabase(executeClosure: @escaping () -> Void) {
      let userSettings = UserDefaults.standard
      if !userSettings.bool(forKey: "subscriptionSaved") {
         let newSubscription = CKDatabaseSubscription(subscriptionID: "updatesDatabase")
         let info = CKSubscription.NotificationInfo()
         info.shouldSendContentAvailable = true
         newSubscription.notificationInfo = info
       
         database.save(newSubscription, completionHandler: { (subscription, error) in
            if error == nil {
               userSettings.set(true, forKey: "subscriptionSaved")
            } else {
               print("Error Creating Subscription")
            }
         })
      }
      if !userSettings.bool(forKey: "zoneCreated") {
         let newZone = CKRecordZone(zoneName: "listPlaces")
         database.save(newZone, completionHandler: { (zone, error) in
            if error == nil {
               userSettings.set(true, forKey: "zoneCreated")
               executeClosure()
            } else {
               print("Error Creating Zone")
            }
         })
      } else {
         executeClosure()
      }
   }
    func checkUpdates(finishClosure: @escaping (UIBackgroundFetchResult) -> Void) {
       self.configureDatabase(executeClosure: {
          let main = OperationQueue.main
          main.addOperation({
             self.downloadUpdates(finishClosure: finishClosure)
          })
       })
    }
    func downloadUpdates(finishClosure: @escaping (UIBackgroundFetchResult) -> Void) {
       var changeToken: CKServerChangeToken!
       var changeZoneToken: CKServerChangeToken!
    
       let userSettings = UserDefaults.standard
       if let data = userSettings.value(forKey: "changeToken") as? Data {
          if let token = try? NSKeyedUnarchiver.unarchivedObject(ofClass: CKServerChangeToken.self, from: data) {
             changeToken = token
          }
       }
       if let data = userSettings.value(forKey: "changeZoneToken") as? Data {
          if let token = try? NSKeyedUnarchiver.unarchivedObject(ofClass: CKServerChangeToken.self, from: data) {
             changeZoneToken = token
          }
       }
       var zonesIDs: [CKRecordZone.ID] = []
       let operation = CKFetchDatabaseChangesOperation(previousServerChangeToken: changeToken)
       operation.recordZoneWithIDChangedBlock = { (zoneID) in
          zonesIDs.append(zoneID)
       }
       operation.changeTokenUpdatedBlock = { (token) in
          changeToken = token
       }
       operation.fetchDatabaseChangesCompletionBlock = { (token, more, error) in
          if error != nil {
             finishClosure(UIBackgroundFetchResult.failed)
          } else if !zonesIDs.isEmpty {
             changeToken = token
    
             let configuration = CKFetchRecordZoneChangesOperation.ZoneConfiguration()
                configuration.previousServerChangeToken = changeZoneToken
             let fetchOperation = CKFetchRecordZoneChangesOperation(recordZoneIDs: zonesIDs, configurationsByRecordZoneID: [zonesIDs[0]: configuration])
        
             fetchOperation.recordChangedBlock = { (record) in
                let main = OperationQueue.main
                main.addOperation {
                   if record.recordType == "Countries" {
                      let index = self.listCountries.firstIndex(where: { (item) in
                         return item.id == record.recordID
                      })
                      let newCountry = Country(name: record["name"], record: record)
                      let newItem = CountryViewModel(id: record.recordID, country: newCountry)
                      if index != nil {
                         self.listCountries[index!] = newItem
                      } else {
                         self.listCountries.append(newItem)
                      }
                      self.listCountries.sort(by: { $0.countryName < $1.countryName })
                   }
                }
             }
             fetchOperation.recordWithIDWasDeletedBlock = { (recordID, recordType) in
                let main = OperationQueue.main
                main.addOperation {
                   if recordType == "Countries" {
                      let index = self.listCountries.firstIndex(where: {(item) in
                         return item.id == recordID
                      })
                      if index != nil {
                         self.listCountries.remove(at: index!)
                      }
                      self.listCountries.sort(by: { $0.countryName < $1.countryName })
                   }
                }
             }
             fetchOperation.recordZoneChangeTokensUpdatedBlock = { (zoneID, token, data) in
                changeZoneToken = token
             }
             fetchOperation.recordZoneFetchCompletionBlock = { (zoneID, token, data, more, error) in
                if error != nil {
                   print("Error")
                } else {
                   changeZoneToken = token
                }
             }
             fetchOperation.fetchRecordZoneChangesCompletionBlock = { (error) in
                if error != nil {
                   finishClosure(UIBackgroundFetchResult.failed)
                } else {
                   if changeToken != nil {
                      if let data = try? NSKeyedArchiver.archivedData(withRootObject: changeToken!, requiringSecureCoding: false) {
                         userSettings.set(data, forKey: "changeToken")
                      }
                   }
                   if changeZoneToken != nil {
                      if let data = try? NSKeyedArchiver.archivedData(withRootObject: changeZoneToken!, requiringSecureCoding: false) {
                         userSettings.set(data, forKey: "changeZoneToken")
                      }
                   }
                   finishClosure(UIBackgroundFetchResult.newData)
                }
             }
             self.database.add(fetchOperation)
          } else {
             finishClosure(UIBackgroundFetchResult.noData)
          }
       }
       database.add(operation)
    }
    
    func checkZones() {
        let newZone = CKRecordZone(zoneName: "myNewZone")
        database.fetch(withRecordZoneID: newZone.zoneID, completionHandler: {(zone, error) in
            if let error = error as? CKError {
                if error.code == CKError.Code.zoneNotFound {
                    print("Not found")
                } else {
                    print("Zone Found")
                }
            }
        })
    }
}
