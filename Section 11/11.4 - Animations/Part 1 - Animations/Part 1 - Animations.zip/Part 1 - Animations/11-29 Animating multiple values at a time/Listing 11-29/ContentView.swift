
import SwiftUI

struct ContentView: View {
   @State private var boxScale: CGFloat = 1
   @State private var roundCorners: Bool = false

   var body: some View {
      VStack {
         HStack {
            Rectangle()
               .fill(Color.blue)
               .frame(width: 50, height: 50)
               .cornerRadius(roundCorners ? 50 : 0)
               .scaleEffect(boxScale)
               .animation(
                  Animation.easeInOut(duration: 2)
               )
         }
         .frame(width: 250, height: 120)
         Button("Animate") {
            self.boxScale = 2
            self.roundCorners.toggle()
         }
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
