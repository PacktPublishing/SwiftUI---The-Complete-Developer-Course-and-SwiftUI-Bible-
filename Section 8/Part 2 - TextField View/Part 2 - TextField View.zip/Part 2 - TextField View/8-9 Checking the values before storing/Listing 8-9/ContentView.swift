
import SwiftUI

class ContentViewData: ObservableObject {
   @Published var title: String = "Default Name"
   @Published var nameInput: String = ""
   @Published var surnameInput: String = ""
   @Published var colorName: Color = Color.white
   @Published var colorSurname: Color = Color.white
}
struct ContentView: View {
   @ObservedObject var contentData = ContentViewData()
   var colors = [Color.white, Color(red: 0.9, green: 0.9, blue: 0.9)]

   var body: some View {
      VStack(spacing: 10) {
         Text(contentData.title)
            .lineLimit(1)
            .padding()
            .background(Color.yellow)
         TextField("Insert Name", text: $contentData.nameInput, onEditingChanged: { self.contentData.colorName = $0 ? self.colors[1] : self.colors[0] })
            .padding(8)
            .background(contentData.colorName)
         TextField("Insert Surname", text: $contentData.surnameInput, onEditingChanged: { self.contentData.colorSurname = $0 ? self.colors[1] : self.colors[0] })
            .padding(8)
            .background(contentData.colorSurname)
         HStack {
            Spacer()
            Button("Save") {
               let tempName = self.contentData.nameInput.trimmingCharacters(in: .whitespaces)
               let tempSurname = self.contentData.surnameInput.trimmingCharacters(in: .whitespaces)
            
               if !tempName.isEmpty && !tempSurname.isEmpty {
                  self.contentData.title = tempName + " " + tempSurname
                  self.contentData.colorName = self.colors[0]
                  self.contentData.colorSurname = self.colors[0]
               }
            }
         }
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
