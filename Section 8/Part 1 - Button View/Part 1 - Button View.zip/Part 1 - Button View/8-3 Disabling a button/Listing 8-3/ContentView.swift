
import SwiftUI

struct ContentView: View {
   @State private var title: String = "Default Title"
   @State private var color = Color.clear
   @State private var buttonDisabled = false

   var body: some View {
      VStack(spacing: 10) {
         Text(title)
            .padding()
            .background(color)
         Button("Change Color") {
            self.color = Color.green
            self.buttonDisabled = true
         }
         .accentColor(Color.green)
         .disabled(buttonDisabled)
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
