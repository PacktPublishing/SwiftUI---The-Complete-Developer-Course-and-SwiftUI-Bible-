
import SwiftUI

struct ContentView: View {
   @State private var title: String = "Default Title"
   @State private var expanded: Bool = false
    
   var body: some View {
      VStack(spacing: 10) {
         Text(title)
            .frame(width: expanded ? 300 : 150, height: 50)
            .background(Color.yellow)
         Button(action: {
            self.expanded.toggle()
         }, label: {
            VStack {
               Image("expand")
                  .renderingMode(.original)
               Text("Expand")
            }
         })
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
