
import SwiftUI

struct Book {
   var title: String
   var author: String
   var cover: String
   var year: Int
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var cover: String {
      return book.cover
   }
   var year: String {
      return String(book.year)
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel] = []

   @Published var search: String? = nil
   @Published var searchInput: String = "" {
      didSet {
         setSearch(term: searchInput)
      }
   }
   var filteredList: [BookViewModel] {
      if let searchText = search {
         return userData.filter({ $0.title.contains(searchText) })
      } else {
         return userData
      }
   }
   func setSearch(term: String) {
      let toSearch = term.trimmingCharacters(in: .whitespaces)
      search = toSearch == "" ? nil : toSearch
   }
}
