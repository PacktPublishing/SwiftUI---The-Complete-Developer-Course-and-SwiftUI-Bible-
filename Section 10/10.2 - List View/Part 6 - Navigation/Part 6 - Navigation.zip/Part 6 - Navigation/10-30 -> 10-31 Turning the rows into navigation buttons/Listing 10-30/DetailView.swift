
import SwiftUI

struct DetailView: View {
   let book: BookViewModel

   var body: some View {
      VStack {
         Image(book.cover)
            .resizable()
            .scaledToFit()
         Text(book.title)
         Text(book.author)
      }.padding()
      .navigationBarTitle("Book")
   }
}
struct DetailView_Previews: PreviewProvider {
   static var previews: some View {
      NavigationView {
         DetailView(book: BookViewModel(book: Book(title: "Steve Jobs", author: "Walter Isaacson", cover: "book1", year: 2011)))
      }
   }
}
