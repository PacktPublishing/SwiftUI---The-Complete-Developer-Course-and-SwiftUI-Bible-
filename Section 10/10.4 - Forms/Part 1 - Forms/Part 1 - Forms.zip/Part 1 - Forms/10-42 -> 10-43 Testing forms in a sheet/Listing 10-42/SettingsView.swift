
import SwiftUI

struct SettingsView: View {
   @Binding var setCity: String
   @Environment(\.presentationMode) var presentation
   let listCities: [String] = ["Paris", "Toronto", "Dublin"]

   var body: some View {
      NavigationView {
         Form {
            Picker("", selection: $setCity) {
               ForEach(listCities, id: \.self) { city in
                  Text(city)
               }
            }.labelsHidden()
         }
         .navigationBarTitle("Settings")
         .navigationBarItems(trailing: Button("Save") {
            self.presentation.wrappedValue.dismiss()
         })
      }
      .navigationViewStyle(StackNavigationViewStyle())
   }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView(setCity: .constant("Undefined"))
    }
}
