
import SwiftUI

struct ContentView: View {
   @State private var setCity: String = "Paris"
   let listCities: [String] = ["Paris", "Toronto", "Dublin"]

   var body: some View {
      NavigationView {
         Form {
            Section(header: Text(setCity).font(.headline)) {
               Picker("", selection: $setCity) {
                  ForEach(listCities, id: \.self) { city in
                     Text(city)
                  }
               }.labelsHidden()
               .pickerStyle(WheelPickerStyle())
            }.frame(minWidth: 0, maxWidth: .infinity)
         }.navigationBarTitle("Settings")
      }
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
