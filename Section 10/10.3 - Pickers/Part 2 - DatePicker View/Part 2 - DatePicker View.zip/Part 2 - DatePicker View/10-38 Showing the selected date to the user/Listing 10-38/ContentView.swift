
import SwiftUI

struct ContentView: View {
   @State private var selectedDate: Date = Date()
   @State private var message: String = ""

   var body: some View {
      VStack(spacing: 10) {
         DatePicker("", selection: $selectedDate, displayedComponents: .date)
            .labelsHidden()
         Text("Date: \(message)")

         Button("Select Date") {
            let format = DateFormatter()
            format.dateStyle = DateFormatter.Style.medium
            self.message = format.string(from: self.selectedDate)
         }
         Spacer()
      }.font(.title)
      .padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
