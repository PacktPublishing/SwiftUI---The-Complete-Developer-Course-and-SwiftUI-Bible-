
import SwiftUI

enum LengthType: String, CaseIterable, Hashable {
   case mm = "Millimeters"
   case cm = "Centimeters"
   case m = "Meters"
   case km = "Kilometers"
   case inch = "Inches"
   case ft = "Feet"
   case yd = "Yards"
   case mi = "Miles"
   case nmi = "Nautical Miles"
   case none = "Unknown"
}
struct ContentView: View {
   @State private var selectedValue: LengthType = .none

   var body: some View {
      VStack {
      Text(selectedValue.rawValue)
         .font(.largeTitle)
         .padding()
      Picker("", selection: $selectedValue) {
         ForEach(LengthType.allCases, id: \.self) { value in
            Text(value.rawValue)
               .tag(value)
            }
         }.labelsHidden()
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
