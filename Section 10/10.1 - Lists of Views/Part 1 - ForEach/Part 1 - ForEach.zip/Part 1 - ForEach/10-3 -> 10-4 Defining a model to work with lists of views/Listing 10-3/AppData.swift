
import SwiftUI

struct Book {
   var title: String
   var author: String
   var cover: String
   var year: Int
}
struct BookViewModel: Identifiable {
   var id = UUID()
   var book: Book

   var title: String {
      return book.title.capitalized
   }
   var author: String {
      return book.author.capitalized
   }
   var cover: String {
      return book.cover
   }
   var year: String {
      return String(book.year)
   }
}
class AppData: ObservableObject {
   @Published var userData: [BookViewModel]
 
   init() {
      userData = [
         BookViewModel(book: Book(title: "Steve Jobs", author: "Walter Isaacson", cover: "book1", year: 2011)),
         BookViewModel(book: Book(title: "HTML5 for Masterminds", author: "J.D Gauchat", cover: "book2", year: 2017)),
         BookViewModel(book: Book(title: "The Road Ahead", author: "Bill Gates", cover: "book3", year: 1995))
      ]
   }
}

