
import SwiftUI

struct AddBookView: View {
   @EnvironmentObject var appData: AppData
   @Environment(\.presentationMode) var presentation
    
   @State private var newTitle: String = ""
   @State private var newAuthor: String = ""
   @State private var newYear: String = ""
    
   var body: some View {
      VStack(spacing: 15) {
         Text("Add Book")
            .font(.largeTitle)
         TextField("Insert the Title", text: $newTitle)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert the Author", text: $newAuthor)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert the Year", text: $newYear)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         HStack {
            Spacer()
            Button("Save Book") {
               let title = self.newTitle.trimmingCharacters(in: .whitespaces)
               let author = self.newAuthor.trimmingCharacters(in: .whitespaces)
               if let year = Int(self.newYear), !title.isEmpty, !author.isEmpty {
                  let newBook = Book(title: title, author: author, cover: "nopicture", year: year)
                  self.appData.addBook(book: newBook)
                  self.presentation.wrappedValue.dismiss()
               }
            }
         }
         Spacer()
      }.padding(20)
   }
}
struct AddBookView_Previews: PreviewProvider {
    static var previews: some View {
        AddBookView()
    }
}
