
import SwiftUI

struct ContentView: View {
   @State private var title: String = "Default Title"
   @State private var titleActive: Bool = false
   @State private var titleInput: String = ""

   var body: some View {
      VStack {
         Text(title)
            .padding(10)
            .foregroundColor(titleActive ? Color.red : Color.gray)
         TextField("Insert Title", text: $titleInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Button(action: {
            self.title = self.titleInput
            self.titleActive = true
            self.titleInput = ""
         }, label: { Text("Change Title") })
         Spacer()
      }.padding()
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
