
import SwiftUI

class ContentViewData: ObservableObject {
   @Published var titleInput: String = ""
   @Published var authorInput: String = ""
}
struct ContentView: View {
   @ObservedObject var contentData = ContentViewData()
   @EnvironmentObject var appData: AppData

   var body: some View {
      VStack(spacing: 8) {
         Text(appData.userData.header)
            .padding(10)
         TextField("Insert Title", text: $contentData.titleInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert Author", text: $contentData.authorInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Button(action: {
            self.appData.userData.book.title = self.contentData.titleInput
            self.appData.userData.book.author = self.contentData.authorInput
         }, label: { Text("Save") })
         Spacer()
      }.padding()
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView().environmentObject(AppData())
   }
}
