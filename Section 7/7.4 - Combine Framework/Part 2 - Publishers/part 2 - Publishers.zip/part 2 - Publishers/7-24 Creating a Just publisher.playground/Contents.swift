import Foundation
import Combine

let myPublisher = Just("55")
