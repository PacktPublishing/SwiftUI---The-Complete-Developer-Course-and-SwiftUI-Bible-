
import SwiftUI

class ContentViewData: ObservableObject {
   @Published var counter: Int = 0

   let timerPublisher = Timer.publish(every: 2, on: RunLoop.main, in: .common)
      .autoconnect()
}
struct ContentView: View {
   @ObservedObject var contentData = ContentViewData()

   var body: some View {
      Text("Counter: \(contentData.counter)")
         .onReceive(contentData.timerPublisher, perform: { value in
            self.contentData.counter += 1
         })
   }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
