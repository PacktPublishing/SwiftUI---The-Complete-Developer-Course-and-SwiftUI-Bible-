
import SwiftUI

class AppData: ObservableObject {
   @Published var title: String = "Default Title"
   @Published var author: String = "Unknown"
}
