
import SwiftUI

struct ContentView: View {
   @ObservedObject var appData: AppData

   var body: some View {
      VStack(spacing: 8) {
         Text("\(appData.title) - \(appData.author)")
            .padding(10)
         TextField("Insert Title", text: $appData.titleInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         TextField("Insert Author", text: $appData.authorInput)
            .textFieldStyle(RoundedBorderTextFieldStyle())
         Button(action: {
            self.appData.title = self.appData.titleInput
            self.appData.author = self.appData.authorInput
         }, label: { Text("Save") })
         Spacer()
      }.padding()
   }
}
struct ContentView_Previews: PreviewProvider {
   static var previews: some View {
      ContentView(appData: AppData())
   }
}
