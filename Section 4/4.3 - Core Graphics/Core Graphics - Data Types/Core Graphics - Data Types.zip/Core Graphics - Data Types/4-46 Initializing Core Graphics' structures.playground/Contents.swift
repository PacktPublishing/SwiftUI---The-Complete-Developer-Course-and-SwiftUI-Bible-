import CoreGraphics

var myfloat: CGFloat = 35
var mysize: CGSize = CGSize(width: 250, height: 250)
var mypoint: CGPoint = CGPoint(x: 20, y: 50)
var myrect: CGRect = CGRect(origin: mypoint, size: mysize)
var myvector: CGVector = CGVector(dx: 30, dy: 30)
