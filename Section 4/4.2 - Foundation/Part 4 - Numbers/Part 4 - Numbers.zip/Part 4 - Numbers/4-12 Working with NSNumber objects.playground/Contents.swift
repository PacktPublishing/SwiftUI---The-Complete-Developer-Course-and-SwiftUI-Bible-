import Foundation

var number = NSNumber(value: 35)
var double = number.doubleValue * 2  // 70
