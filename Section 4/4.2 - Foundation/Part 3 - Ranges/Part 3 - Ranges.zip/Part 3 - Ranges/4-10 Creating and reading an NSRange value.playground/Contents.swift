import Foundation

let range = NSRange(4..<10)
print("Initial: \(range.location)")  // "Initial: 4"
print("Length: \(range.length)")  // "Length: 6"
