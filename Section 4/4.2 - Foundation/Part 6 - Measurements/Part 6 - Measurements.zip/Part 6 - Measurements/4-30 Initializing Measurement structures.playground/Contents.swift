import Foundation

var length = Measurement(value: 30, unit: UnitLength.centimeters) // 30.0 cm
var weight = Measurement(value: 5, unit: UnitMass.pounds)  // 5.0 lb
